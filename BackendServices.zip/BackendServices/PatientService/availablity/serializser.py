from rest_framework import serializers
from .models import DoctorAvailability
from DoctorService.models import DoctorDetails

class DoctorAvailabilitySerializer(serializers.ModelSerializer):
    doctor_id = serializers.CharField(source="doctor.reg_id", read_only=True)  # Ensure doctor_id is serialized properly

    class Meta:
        model = DoctorAvailability
        fields = ['doctor_id', 'day', 'time_slot', 'status']  # Use doctor_id instead of doctor
