import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import "../../css/UserCss/ViewAppointment.css";
import CustomAlert from '../CustomeAlert';

const ViewAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [doctorNames, setDoctorNames] = useState({});
  const [currentPage, setCurrentPage] = useState(1);
  const recordsPerPage = 13;

  const userId = localStorage.getItem("user_id");
  const hasFetched = useRef(false); 
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success');

  useEffect(() => {
    const fetchData = async () => {
      if (hasFetched.current || !userId) return; 
      hasFetched.current = true;

      try {
        const response = await axios.get(`http://localhost:8003/appointments/User/${userId}`);
        const appointmentsData = response.data;

        const doctorRequests = appointmentsData.map((appt) =>
          axios.get(`http://localhost:8002/doctor/doctor/id/${appt.doctorId}/`)
        );
        const doctorResponses = await Promise.all(doctorRequests);

        const doctorNamesMap = doctorResponses.reduce((acc, response) => {
          const doctor = response.data;
          acc[doctor.reg_id] = doctor.name;
          return acc;
        }, {});

        setAppointments(appointmentsData);
        setDoctorNames(doctorNamesMap);

        setAlertMessage("Data received from backend");
        setAlertVariant("success");
        setShowAlert(true);
      } catch (err) {
        setAlertMessage("Failed to fetch data");
        setAlertVariant("danger");
        setShowAlert(true);
      }
    };

    fetchData();
  }, [userId]);

  const appointmentsWithDoctorNames = appointments.map((appt) => ({
    ...appt,
    doctorName: doctorNames[appt.doctorId] || "Loading...",
  }));

  // Pagination Logic
  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const currentRecords = appointmentsWithDoctorNames.slice(indexOfFirstRecord, indexOfLastRecord);

  const totalPages = Math.ceil(appointmentsWithDoctorNames.length / recordsPerPage);

  const handleNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };

  const handlePrevPage = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };

  return (
    <>
      <CustomAlert
        show={showAlert}
        message={alertMessage}
        variant={alertVariant}
        onClose={() => setShowAlert(false)}
      />

      <div className="view-appointments">
        <h2>View Appointments</h2>

        <table className="appointments-table">
          <thead>
            <tr>
              <th>Doctor</th>
              <th>Date</th>
              <th>Time</th>
              <th>Status</th>
              <th>Appointment Type</th>
              <th>Symptoms</th>
              <th>Communication Mode</th>
            </tr>
          </thead>
          <tbody>
            {currentRecords.length === 0 ? (
              <tr>
                <td colSpan="7">No appointments available.</td>
              </tr>
            ) : (
              currentRecords.map((appt) => (
                <tr key={appt.id}>
                  <td>{appt.doctorName}</td>
                  <td>{appt.appointmentDate}</td>
                  <td>{appt.appointmentTime}</td>
                  <td>{appt.complete ? "Completed" : "Pending"}</td>
                  <td>{appt.complete ? "Past" : "Upcoming"}</td>
                  <td>{appt.symptoms}</td>
                  <td>{appt.communicationMode}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        {/* Pagination Buttons */}
        <div className="pagination">
          <button onClick={handlePrevPage} disabled={currentPage === 1}>
            Previous
          </button>
          <span> Page {currentPage} of {totalPages} </span>
          <button onClick={handleNextPage} disabled={currentPage === totalPages}>
            Next
          </button>
        </div>
      </div>
    </>
  );
};

export default ViewAppointments;
