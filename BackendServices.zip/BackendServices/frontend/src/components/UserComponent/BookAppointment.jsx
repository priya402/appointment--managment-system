import React, { useState, useEffect } from "react";
import "../../css/UserCss/BookAppointment.css";
import axios from "axios";
import CustomAlert from '../CustomeAlert'
const BookAppointment = () => {
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
 
  const [formData, setFormData] = useState({
    userName: "", // Updated from 'name' to 'userName' to match backend
    doctorId: "", // Updated from 'doctor' to 'doctorId' to match backend
    appointmentDate: "", // Updated from 'date' to 'appointmentDate' to match backend
    appointmentTime: "", // Updated from 'time' to 'appointmentTime' to match backend
    symptoms: "",
    communicationMode: "",
    userId: localStorage.getItem("user_id"),
  });
  
  const convertTo24HourFormat = (time) => {
    const [hour, minuteWithPeriod] = time.split(":");
    const [minute, period] = minuteWithPeriod.split(" ");
    let hour24 = parseInt(hour);
  
    if (period === "PM" && hour !== "12") {
      hour24 += 12;
    }
  
    if (period === "AM" && hour === "12") {
      hour24 = 0;
    }
  
    return `${hour24.toString().padStart(2, '0')}:${minute}`;
  };
  

  const [confirmationMessage, setConfirmationMessage] = useState("");

  // Fetch doctors from the backend API
  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        const response = await axios.get("http://localhost:8002/doctor/doctor/"); // Replace with your backend endpoint
        if (response.data && response.data.length > 0) {
          setDoctors(response.data);
          setAlertMessage("Fetched Data");
          setAlertVariant("success");
          setShowAlert(true);
   
   
        } else {
          setAlertMessage("No doctors available.");
          setAlertVariant("success");
          setShowAlert(true);
   
   
        }
      } catch (err) {
        
        setAlertMessage("Failed to fetch doctors. Please try again later.");
        setAlertVariant("danger");
        setShowAlert(true);
 
      } finally {
        setLoading(false);
      }
    };

    fetchDoctors();
  }, []);

  const handleChange = (e) => {
    
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic form validation
    if (
      !formData.userName ||
      !formData.doctorId ||
      !formData.appointmentDate ||
      !formData.appointmentTime ||
      !formData.symptoms ||
      !formData.communicationMode
    ) {
      setAlertMessage("Fill All Values");
      setAlertVariant("danger");
      setShowAlert(true);

     return;
    }

    // Send form data to the appointment service
    try {
      const response = await axios.post("http://localhost:8003/appointments/", formData); // Replace with your backend endpoint
      setAlertMessage(response.data.message || "Appointment booked successfully!");
      setAlertVariant("success");
      setShowAlert(true);
    } catch (error) {
      setAlertMessage("An error occurred while booking the appointment");
      setAlertVariant("danger");
      setShowAlert(true);


    }
  };

  return (
    <>
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        />
    <div className="book-appointment">
      <h2>Book an Appointment</h2>
    <div className="container">
      <form className="appointment-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="userName">Your Name</label>
          <input
            type="text"
            id="userName"
            name="userName"
            value={formData.userName}
            onChange={handleChange}
            placeholder="Enter your full name"
          />
        </div>

        <div className="form-group">
          <label htmlFor="doctorId">Select Doctor</label>
          {loading ? (
            <p>Loading doctors...</p>
          ) : error ? (
            <p className="error-message">{error}</p>
          ) : (
            <select
              id="doctorId"
              name="doctorId"
              value={formData.doctorId}
              onChange={handleChange}
            >
              <option value="">Select a doctor</option>
              {doctors.map((doctor) => (
                <option key={doctor.reg_id} value={doctor.reg_id}>
                  {doctor.name}
                </option>
              ))}
            </select>
          )}
        </div>

        <div className="form-group">
          <label htmlFor="appointmentDate">Select Date</label>
          <input
            type="date"
            id="appointmentDate"
            name="appointmentDate"
            value={formData.appointmentDate}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="appointmentTime">Select Time</label>
          <select
            id="appointmentTime"
            name="appointmentTime"
            value={formData.appointmentTime}
            onChange={handleChange}
          >
            <option value="">Select a time</option>
            {["10:00 AM", "11:30 AM", "1:00 PM", "2:00 PM", "3:30 PM"].map((time, index) => (
              <option key={index} value={convertTo24HourFormat(time)}>
                {time}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="symptoms">Symptoms / Reason for Visit</label>
          <textarea
            id="symptoms"
            name="symptoms"
            value={formData.symptoms}
            onChange={handleChange}
            placeholder="Describe your symptoms or reason for the visit"
          />
        </div>

        <div className="form-group">
          <label htmlFor="communicationMode">Preferred Communication Mode</label>
          <select
            id="communicationMode"
            name="communicationMode"
            value={formData.communicationMode}
            onChange={handleChange}
          >
            <option value="">Select communication mode</option>
            {["Phone", "Video Call", "In-Person"].map((mode, index) => (
              <option key={index} value={mode}>
                {mode}
              </option>
            ))}
          </select>
        </div>

        <button type="submit" className="submit-button" disabled={loading || error}>
          Book Appointment
        </button>
      </form>
</div>
    </div>
    </>
  );
};

export default BookAppointment;
