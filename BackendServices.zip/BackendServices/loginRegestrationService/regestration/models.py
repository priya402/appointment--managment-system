from django.db import models

# Create your models here.
from mongoengine import Document, StringField, EmailField, BooleanField,DateTimeField
from mongoengine.errors import ValidationError
import re
from datetime import datetime, timedelta

class User(Document):
    email = EmailField(required=True, unique=True)
    name = StringField(max_length=100, required=True)
    phone_number = StringField(max_length=10, required=True)
    address = StringField(max_length=255, required=False)
    role = StringField(choices=["user", "admin","doctor"], default="user")
    hospital_key = StringField(max_length=11, required=False)
    is_active = BooleanField(default=True)

    meta = {'collection': 'users'}

    def clean(self):
        """
        Custom validation before saving data
        """
        # Validate name length (minimum 3 characters)
        if len(self.name) < 3:
            raise ValidationError("Name must be at least 3 characters long.")

        # Validate phone number (only digits, exactly 10 characters)
        if not re.fullmatch(r'^\d{10}$', self.phone_number):
            raise ValidationError("Phone number must be exactly 10 digits.")

        # Validate address (if provided, must be at least 5 characters)
        if self.address and len(self.address) < 5:
            raise ValidationError("Address must be at least 5 characters long.")

        # Validate hospital_key format (if provided, must match: ABC1234567)
        if self.hospital_key and not re.fullmatch(r'[A-Za-z]{3}\d{7}', self.hospital_key):
            raise ValidationError("Hospital key must be in the format ABC1234567.")




class TempUser(Document):
    email = StringField(required=True, unique=True)
    name = StringField(required=True)
    phone_number = StringField(required=True)
    address = StringField(required=True)
    role = StringField(required=True)
    hospital_key = StringField()
    otp = StringField(required=True)
    created_at = DateTimeField(default=datetime.utcnow)
    last_otp_sent_time = DateTimeField()

    meta = {'collection': 'temp_users'}