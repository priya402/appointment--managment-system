from rest_framework import serializers
from .models import Appointment

class AppointmentSerializer(serializers.Serializer):
    id = serializers.CharField(read_only=True)  # MongoDB will handle _id automatically, but you can map it to 'id'
    user_email = serializers.EmailField()
    user_name = serializers.CharField(max_length=100)
    otp = serializers.CharField(max_length=6, required=False)
    appointment_date = serializers.DateTimeField(required=False)
    created_at = serializers.DateTimeField(read_only=True)
    mail_type = serializers.ChoiceField(choices=Appointment.MAIL_TYPES, default="CUSTOM_MESSAGE")

    def create(self, validated_data):
        # Create a new Appointment document
        appointment = Appointment(**validated_data)
        appointment.save()  # Save the document to MongoDB
        return appointment

    def update(self, instance, validated_data):
        # Update an existing Appointment document
        for key, value in validated_data.items():
            setattr(instance, key, value)
        instance.save()  # Save the updated document
        return instance
