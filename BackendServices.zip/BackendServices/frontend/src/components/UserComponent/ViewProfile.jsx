import React, { useState, useEffect } from "react";
import axios from "axios";
import "../../css/UserCss/ViewProfile.css";
import CustomAlert from '../CustomeAlert'
const ViewProfile = () => {
  const [userData, setUserData] = useState({});
  const [isEditable, setIsEditable] = useState(false);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showAlert, setShowAlert] = useState(false);
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
  const [alertMessage, setAlertMessage] = useState('');


  const patient_id = localStorage.getItem("user_id"); // Assuming user ID is stored in localStorage

  // Fetch user details when the component loads
  useEffect(() => {
    axios
      .get(`http://localhost:8002/pationt/patientsDetails/id/${patient_id}/`)
      .then((response) => {
        setUserData(response.data);
        setAlertMessage("Found Patient");
        setAlertVariant("success");
        setShowAlert(true);
 
 
        setLoading(false);
      })
      .catch((err) => {
        
        setLoading(false);
        setAlertVariant('danger')
        setShowAlert(true)
        setAlertMessage("Failed to load user details.")
      });
  }, [patient_id]);

  const handleEditToggle = () => {
    setIsEditable(!isEditable);
  };

  const handleSave = () => {
    axios
      .put(`http://localhost:8002/pationt/patientsDetails/update/${patient_id}/`, userData)
      .then((res) => {
        setIsEditable(false);
        setLoading(false);
        setAlertMessage("data saved")
        setAlertVariant('success')
        setShowAlert(true)      })
      .catch((err) => {
        setAlertMessage("Failed to update profile.")
        setAlertVariant('danger')
        setShowAlert(true)     
      });
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setUserData({ ...userData, profile_image: e.target.result });
      };
      reader.readAsDataURL(file);
    }
  };

  const closeImageModal = () => {
    setIsImageModalOpen(false);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div className="error">{error}</div>;
  }

  return (
    <div className="view-profile">
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        />
      <h2>View Profile</h2>
      <div className="profile-container">
        <div className="profile-image-container">
          {/* Display image from base64 data */}
          <img
            src={userData.profile_image}
            alt="Profile"
            className="profile-image"
            onClick={() => setIsImageModalOpen(true)}
          />
          <p>Click image to update</p>
        </div>

        <form className="profile-form">
          <div className="form-group">
            <label>Patient ID:</label>
            <input
              type="text"
              value={userData.patient_id || ""}
              disabled
            />
          </div>
          <div className="form-group">
            <label>Name:</label>
            <input
              type="text"
              value={userData.name || ""}
              disabled={!isEditable}
              onChange={(e) =>
                setUserData({ ...userData, name: e.target.value })
              }
            />
          </div>
          <div className="form-group">
            <label>Email:</label>
            <input
              type="email"
              value={userData.email || ""}
              disabled={!isEditable}
              onChange={(e) =>
                setUserData({ ...userData, email: e.target.value })
              }
            />
          </div>
          <div className="form-group">
            <label>Phone:</label>
            <input
              type="text"
              value={userData.phone || ""}
              disabled={!isEditable}
              onChange={(e) =>
                setUserData({ ...userData, phone: e.target.value })
              }
            />
          </div>
          <div className="form-group">
            <label>Date of Birth:</label>
            <input
              type="date"
              value={userData.dob || ""}
              disabled={!isEditable}
              onChange={(e) =>
                setUserData({ ...userData, dob: e.target.value })
              }
            />
          </div>
          <div className="form-group">
            <label>Gender:</label>
            <select
              value={userData.gender || ""}
              disabled={!isEditable}
              onChange={(e) =>
                setUserData({ ...userData, gender: e.target.value })
              }
            >
              <option value="">Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div className="form-group">
            <label>Address Line 1:</label>
            <input
              type="text"
              value={userData.address_line1 || ""}
              disabled={!isEditable}
              onChange={(e) =>
                setUserData({ ...userData, address_line1: e.target.value })
              }
            />
          </div>
          <div className="form-group">
            <label>City:</label>
            <input
              type="text"
              value={userData.city || ""}
              disabled={!isEditable}
              onChange={(e) =>
                setUserData({ ...userData, city: e.target.value })
              }
            />
          </div>
          <div className="form-group">
            <label>State:</label>
            <input
              type="text"
              value={userData.state || ""}
              disabled={!isEditable}
              onChange={(e) =>
                setUserData({ ...userData, state: e.target.value })
              }
            />
          </div>
          <div className="form-group">
            <label>ZIP Code:</label>
            <input
              type="text"
              value={userData.zip_code || ""}
              disabled={!isEditable}
              onChange={(e) =>
                setUserData({ ...userData, zip_code: e.target.value })
              }
            />
          </div>

          <div className="form-actions">
            {!isEditable ? (
              <button
                type="button"
                className="edit-btn"
                onClick={handleEditToggle}
              >
                Edit
              </button>
            ) : (
              <button
                type="button"
                className="save-btn"
                onClick={handleSave}
              >
                Save
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Modal for Image Upload */}
      {isImageModalOpen && (
        <div className="image-modal">
          <div className="modal-content">
            <h3>Update Profile Image</h3>
            <img
              src={userData.profile_image }
              alt="Current Profile"
              className="profile-image"
            />
            <input
              type="file"
              className="upload-input"
              accept="image/*"
              onChange={handleImageUpload}
            />
            <div className="popup-actions">
              <button onClick={closeImageModal} className="cancel-btn">
                Cancel
              </button>
              <button
                onClick={() => {
                  closeImageModal();
                  alert("Profile image updated!");
                }}
                className="save-btn"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ViewProfile;
