import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/AuthPage.css';
import CustomAlert from './CustomeAlert'; // Import the custom alert component
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const AuthPage = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('login');  // Default to 'login'
  const [email, setEmail] = useState('');
  const [otpSentLogin, setOtpSentLogin] = useState(false); // OTP for login
  const [otpSentRegister, setOtpSentRegister] = useState(false); // OTP for register
  const [otpConfirmed, setOtpConfirmed] = useState(false);  // To track OTP confirmation
  const [otpLogin, setOtpLogin] = useState(['', '', '', '', '', '']); // OTP for login
  const [otpRegister, setOtpRegister] = useState(['', '', '', '', '', '']); // OTP for register
  const [role, setRole] = useState('user');
  const [hospitalKey, setHospitalKey] = useState('');
  const [name, setName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [address, setAddress] = useState('');
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info

  const [timerLogin, setTimerLogin] = useState(30);  // Timer for OTP input in login
  const [timerRegister, setTimerRegister] = useState(30); // Timer for OTP input in register
  const [timerActiveLogin, setTimerActiveLogin] = useState(false);  // To track if timer is active for login
  const [timerActiveRegister, setTimerActiveRegister] = useState(false);  // To track if timer is active for register
  const [otpRequestInProgress, setOtpRequestInProgress] = useState(false); // To prevent sending OTP multiple times
 
  // Effect to handle OTP timers
  useEffect(() => {
    let interval;
    if (timerActiveLogin && timerLogin > 0) {
      interval = setInterval(() => {
        setTimerLogin((prev) => prev - 1);
      }, 1000);
    } else if (timerLogin === 0 && !otpConfirmed) { // Ensure OTP is not already confirmed
      resetOtpState("login");
    }

    return () => clearInterval(interval); // Clean up the interval
  }, [timerLogin, timerActiveLogin, otpConfirmed]);


  useEffect(() => {
    let interval;
    if (timerActiveRegister && timerRegister > 0) {
      interval = setInterval(() => {
        setTimerRegister((prev) => prev - 1);
      }, 1000);
    } else if (timerRegister === 0 && !otpConfirmed) {
      resetOtpState("register");
    }

    return () => clearInterval(interval);
  }, [timerRegister, timerActiveRegister, otpConfirmed]);

  // Reset OTP state when expired
  const resetOtpState = (type) => {
    if (type === "login") {
      setOtpLogin(["", "", "", "", "", ""]);
      setTimerLogin(30);
      setTimerActiveLogin(false);
      setOtpSentLogin(false);
    } else {
      setOtpRegister(["", "", "", "", "", ""]);
      setTimerRegister(30);
      setTimerActiveRegister(false);
      setOtpSentRegister(false);
    }
    setAlertMessage("OTP expired. Please send OTP again.");
    setAlertVariant("danger");
    setShowAlert(true);
  };

  // Handle OTP send for login
  const handleSendOtpLogin = async () => {
    setOtpRequestInProgress(false)
    if (email && !otpRequestInProgress) {
      setOtpRequestInProgress(true);
      setTimerRegister(30);
      setTimerActiveRegister(false);
      setOtpSentRegister(false);
      try {
        const response = await axios.post("http://localhost:8001/login/login/", {
          email: email,
          action: "send_otp"
        });

        if (response.status === 200) {
          const backendMessage = response.message || "OTP sent successfully";
          setAlertMessage(backendMessage); // Show backend response message
          setAlertVariant("success");
          setShowAlert(true);
          setOtpSentLogin(true);
          setTimerLogin(120);
          setTimerActiveLogin(true);
        } else {
          throw new Error(response.message || "Failed to send OTP");
        }
      } catch (error) {
        setAlertMessage(error.response?.data?.message || "Failed to send OTP. Please try again.");
        setAlertVariant("danger");
        setShowAlert(true);
      } finally {
        setOtpRequestInProgress(false);
      }
    } else if (!email) {
      setAlertMessage("Please enter a valid email");
      setAlertVariant("danger");
      setShowAlert(true);
    }
  };


  // Handle OTP send for registration
  const handleSendOtpRegister = async () => {
    setOtpRequestInProgress(false)
    if (email && !otpRequestInProgress) {
      setOtpRequestInProgress(true);
      setTimerLogin(30);
      setTimerActiveLogin(false);
      setOtpSentLogin(false);
      const data = {
        "email": email,
        "name": name, // Add the rest of the registration fields as required
        "phone_number": phoneNumber,
        "address": address,
        "role": role,
        hospitalKey:hospitalKey,
        action: "register"
      };

      try {
        const response = await axios.post("http://localhost:8001/regestration/register/", data);
        if (response.status === 201) {
          setAlertMessage(response.data?.message);
          setAlertVariant("success");
          setShowAlert(true);
          setOtpSentRegister(true);
          setTimerRegister(120);
          setTimerActiveRegister(true);

        }
        else {
          throw new Error(response.message || "Failed to send OTP");
        }
      } catch (error) {
        setAlertMessage(error.response?.data?.message || "Failed to send OTP. Please try again.");
        setAlertVariant("danger");
        setShowAlert(true);
      }
    } else if (!email) {
      setAlertMessage("Please enter a valid email");
      setAlertVariant("danger");
      setShowAlert(true);
    }
  };

  // Handle OTP change for input fields
  const handleOtpChange = (e, index, type) => {
    const value = e.target.value;
    if (/[^0-9]/.test(value)) return;
    const newOtp = type === "login" ? [...otpLogin] : [...otpRegister];
    newOtp[index] = value;
    type === "login" ? setOtpLogin(newOtp) : setOtpRegister(newOtp);

    if (value && index < 5) {
      document.getElementById(`${type}-otp-input-${index + 1}`).focus();
    }
  };

  // Handle OTP confirmation for login and registration
  const handleConfirmOtp = async () => {

    try {
      let otp = "";
      let endpoint = "";
      let actionType = "";

      if (otpLogin.every((digit) => digit !== "") && otpSentLogin) {
        otp = otpLogin.join(""); // Combine OTP digits into a single string
        endpoint = "http://localhost:8001/login/login/";
        actionType = "login";
      } else if (otpRegister.every((digit) => digit !== "") && otpSentRegister) {
        otp = otpRegister.join(""); // Combine OTP digits into a single string
        endpoint = "http://localhost:8001/regestration/register/";
        actionType = "register";
      } else {
        setAlertMessage("Please complete the OTP");
        setAlertVariant("danger");
        setShowAlert(true);
        return;
      }

      // Send OTP confirmation request to the backend
      const response = await axios.post(endpoint, {
        "email": email,
        "otp": otp,
        action: "validate_otp"
      });

      if (response.status === 200) {
        const backendMessage = response.message || `${actionType} OTP confirmed successfully`;
        setOtpConfirmed(true); // Mark OTP as confirmed
        setTimerActiveLogin(false); // Stop the timer
        setTimerActiveRegister(false)
        setTimerLogin(0); // Reset the timer
        setAlertMessage(backendMessage);
        setAlertVariant("success");
        setShowAlert(true);

        localStorage.setItem("role", response.data['role'])
        localStorage.setItem("auth", response.data['auth_status'])
        localStorage.setItem("user_id", response.data['user_id'])
        localStorage.setItem("hospital_key",response.data['hospital_key'])


        // Add actions for login or registration
        if (actionType === "login") {
          // Proceed with login actions
          // Assuming login API is successful and user data is stored in localStorage
          const role = localStorage.getItem('role'); // Get the role from localStorage

          if (role === 'admin') {
            navigate("/dashboard", { replace: true });
            window.location.reload(); // Navigate to admin dashboard
          } else if (role === 'user') {
            
            navigate("/UserDashboard", { replace: true });
            window.location.reload(); // Navigate to user dashboard
          } else if (role === 'doctor') {
            navigate("/DoctorDashboard", { replace: true });
            window.location.reload(); // Default navigation if role is not found
          }
        } else if (actionType === 'register') {
          setActiveTab('login')
          setOtpConfirmed(false); // Reset OTP confirmation

        }

      } else {
        setAlertMessage(response.data.message || "Failed to confirm OTP");
        setAlertVariant("success");
        setShowAlert(true);
      }
    } catch (error) {
      setAlertMessage(error.response?.data?.message || "An error occurred while confirming OTP");
      setAlertVariant("danger");
      setShowAlert(true);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <ul className="custom-tabs">
          <li
            className={`nav-link ${activeTab === 'login' ? 'active-tab' : ''}`}
            onClick={() => {
              setActiveTab('login');
              setOtpConfirmed(false); // Reset OTP confirmation on tab switch
            }}
          >
            Login
          </li>
          <li
            className={`nav-link ${activeTab === 'register' ? 'active-tab' : ''}`}
            onClick={() => {
              setActiveTab('register');
              setOtpConfirmed(false); // Reset OTP confirmation on tab switch
            }}
          >
            Register
          </li>
        </ul>
        <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        />
        <div className="tab-content mt-4" >

          {/* Login Tab */}
          {activeTab === 'login' && (
            <div>
              <h3 className="auth-heading">Login</h3>
              <form>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">Email</label>
                  <input
                    type="email"
                    className="form-control"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                  />
                </div>
                {!timerActiveLogin && !otpSentLogin && (
                  <button type="button" className="btn custom-btn" onClick={handleSendOtpLogin}>
                    Send OTP
                  </button>
                )}
              </form>

              {otpSentLogin && !otpConfirmed && (
                <div className="otp-section mt-4">
                  <h4>Enter OTP</h4>
                  <div className="otp-input-container">
                    {otpLogin.map((digit, index) => (
                      <input
                        key={index}
                        type="text"
                        maxLength="1"
                        className="otp-input"
                        id={`login-otp-input-${index}`}
                        value={digit}
                        onChange={(e) => handleOtpChange(e, index, 'login')}
                      />
                    ))}
                  </div>
                  <button
                    type="button"
                    className="btn custom-btn mt-3"
                    onClick={handleConfirmOtp}
                  >
                    Confirm OTP
                  </button>
                  {timerActiveLogin && (
                    <p className="timer-text">
                      Time remaining: {Math.floor(timerLogin / 60)}:
                      {String(timerLogin % 60).padStart(2, "0")}
                    </p>
                  )}                </div>
              )}

            </div>
          )}

          {/* Register Tab */}
          {activeTab === 'register' && (
            <div>
              <h3 className="auth-heading">Register</h3>
              <form>
                <div className="mb-3">
                  <label htmlFor="name" className="form-label">Name</label>
                  <input
                    type="text"
                    className="form-control"
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your name"
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">Email</label>
                  <input
                    type="email"
                    className="form-control"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="phoneNumber" className="form-label">Phone Number</label>
                  <input
                    type="tel"
                    className="form-control"
                    id="phoneNumber"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="Enter your phone number"
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="address" className="form-label">Address</label>
                  <input
                    type="text"
                    className="form-control"
                    id="address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Enter your address"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Role</label>
                  <select
                    className="form-control"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                  >
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label htmlFor="hospitalKey" className="form-label">Hospital Key (for Admin)</label>
                  <input
                    type="text"
                    className="form-control"
                    id="hospitalKey"
                    value={hospitalKey}
                    onChange={(e) => setHospitalKey(e.target.value)}
                    placeholder="Enter hospital key (if admin)"
                  />
                </div>
                {!timerActiveRegister && !otpSentRegister && (
                  <button type="button" className="btn custom-btn" onClick={handleSendOtpRegister}>
                    Send OTP
                  </button>
                )}
              </form>

              {otpSentRegister && !otpConfirmed && (
                <div className="otp-section mt-4">
                  <h4>Enter OTP</h4>
                  <div className="otp-input-container">
                    {otpRegister.map((digit, index) => (
                      <input
                        key={index}
                        type="text"
                        maxLength="1"
                        className="otp-input"
                        id={`register-otp-input-${index}`}
                        value={digit}
                        onChange={(e) => handleOtpChange(e, index, 'register')}
                      />
                    ))}
                  </div>
                  <button
                    type="button"
                    className="btn custom-btn mt-3"
                    onClick={handleConfirmOtp}
                  >
                    Confirm OTP
                  </button>
                  {timerActiveRegister && (
                    <p className="timer-text">
                      Time remaining: {Math.floor(timerRegister / 60)}:
                      {String(timerRegister % 60).padStart(2, "0")}
                    </p>
                  )}                  </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
