import React, { useState, useEffect } from "react";
import "../../css/Setting.css";

const SystemSettings = () => {
  const [language, setLanguage] = useState("en");
  const [theme, setTheme] = useState("light");

  useEffect(() => {
    // Apply theme to body
    document.body.className = theme;
    localStorage.setItem("selectedTheme",theme)
  }, [theme]);

  const handleLanguageChange = (e) => {
    const selectedLanguage = e.target.value;
    setLanguage(selectedLanguage);
    console.log("Language set to:", selectedLanguage);
    // Optionally save to localStorage or trigger i18n here
  };

  const handleThemeChange = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    console.log("Theme changed to:", newTheme);
  };

  const handleSaveSettings = () => {
    console.log("System settings saved!");
    console.log("Language:", language);
    console.log("Theme:", theme);
    // You can send these settings to backend if needed
  };

  return (
    <div className="settings-container">
      <header className="header">
        <h2>System Settings</h2>
      </header>
      <div className="settings-form">
        {/* General Settings */}
        <h3 className="section-title">General Settings</h3>
        <div className="form-group">
          <label htmlFor="timezone">Time Zone:</label>
          <select id="timezone" name="timezone">
            <option value="">-- Select Time Zone --</option>
            <option value="UTC-5">UTC-5</option>
            <option value="UTC+0">UTC+0</option>
            <option value="UTC+5">UTC+5</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="language">Default Language:</label>
          <select id="language" name="language" value={language} onChange={handleLanguageChange}>
            <option value="">-- Select Language --</option>
            <option value="en">English</option>
            <option value="es">Spanish</option>
            <option value="fr">French</option>
          </select>
        </div>

        {/* Theme Setting */}
        <div className="form-group">
          <label htmlFor="theme-toggle">Theme:</label>
          <button className="btn btn-toggle" onClick={handleThemeChange}>
            Switch to {theme === "light" ? "Dark" : "Light"} Mode
          </button>
        </div>

        {/* Security Settings */}
        <h3 className="section-title">Security Settings</h3>
        <div className="form-group">
          <label htmlFor="auto-logout">Auto Logout Time (minutes):</label>
          <input type="number" id="auto-logout" name="auto-logout" placeholder="e.g., 15" />
        </div>
        <div className="form-group">
          <label htmlFor="data-encryption">Enable Data Encryption:</label>
          <input type="checkbox" id="data-encryption" name="data-encryption" />
        </div>

        {/* Maintenance Settings */}
        <h3 className="section-title">Maintenance Settings</h3>
        <div className="form-group">
          <label htmlFor="backup-frequency">Backup Frequency:</label>
          <select id="backup-frequency" name="backup-frequency">
            <option value="">-- Select Frequency --</option>
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="maintenance-mode">Enable Maintenance Mode:</label>
          <input type="checkbox" id="maintenance-mode" name="maintenance-mode" />
        </div>

        <div className="action-buttons">
          <button className="btn btn-save" onClick={handleSaveSettings}>
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
};

export default SystemSettings;
