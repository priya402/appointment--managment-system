from django.urls import path
from .views import DoctorDetailsDetail, DoctorDetailsList

urlpatterns = [
    path('doctor/', DoctorDetailsList.as_view(), name='create-patient'),
    path('doctor/email/<str:identifier>/', DoctorDetailsDetail.as_view(), name='patient-detail-email'),
    path('doctor/id/<str:identifier>/', DoctorDetailsDetail.as_view(), name='patient-detail-id'),


]
