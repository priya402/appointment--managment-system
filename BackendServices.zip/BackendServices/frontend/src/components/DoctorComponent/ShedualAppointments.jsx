import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../css/DoctorCss/ScheduleAppointment.css";

const DoctorScheduleAppointment = () => {
  // Dummy patient data
  const patients = [
    { id: 1, name: "Alice Smith" },
    { id: 2, name: "Bob Johnson" },
    { id: 3, name: "Charlie Brown" },
  ];

  // Dummy time slots
  const timeSlots = [
    "9:00 AM - 10:00 AM",
    "10:00 AM - 11:00 AM",
    "11:00 AM - 12:00 PM",
    "1:00 PM - 2:00 PM",
    "2:00 PM - 3:00 PM",
  ];

  // Form state
  const [selectedPatient, setSelectedPatient] = useState("");
  const [appointmentDate, setAppointmentDate] = useState("");
  const [timeSlot, setTimeSlot] = useState("");
  const [message, setMessage] = useState("");

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!selectedPatient || !appointmentDate || !timeSlot) {
      setMessage("Please fill all the fields.");
    } else {
      setMessage("Appointment scheduled successfully!");
      // Add your submit logic here (e.g., API call)
    }
  };

  return (
    <div className="appointment-container">
      <div className="appointment-card">
        <div className="appointment-card-header">
          <h5>Schedule Appointment</h5>
        </div>
        <div className="appointment-card-body">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="patient" className="form-label">
                Patient Name
              </label>
              <select
                id="patient"
                className="form-select"
                value={selectedPatient}
                onChange={(e) => setSelectedPatient(e.target.value)}
                required
              >
                <option value="">Select Patient</option>
                {patients.map((patient) => (
                  <option key={patient.id} value={patient.id}>
                    {patient.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="appointmentDate" className="form-label">
                Appointment Date
              </label>
              <input
                type="date"
                id="appointmentDate"
                className="form-control"
                value={appointmentDate}
                onChange={(e) => setAppointmentDate(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="timeSlot" className="form-label">
                Time Slot
              </label>
              <select
                id="timeSlot"
                className="form-select"
                value={timeSlot}
                onChange={(e) => setTimeSlot(e.target.value)}
                required
              >
                <option value="">Select Time Slot</option>
                {timeSlots.map((slot, index) => (
                  <option key={index} value={slot}>
                    {slot}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-submit">
              <button type="submit" className="form-button">
                Schedule Appointment
              </button>
            </div>

            {message && (
              <div className="form-message">
                {message}
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default DoctorScheduleAppointment;
