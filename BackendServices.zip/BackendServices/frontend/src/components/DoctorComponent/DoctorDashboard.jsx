import React, { useEffect, useState } from "react";
import "../../css/DoctorCss/DoctorDashbard.css"; // Custom CSS file
import moment from "moment"; // For handling date formatting
import CustomAlert from '../CustomeAlert'
const DoctorDashboard = () => {
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
 
 
  const [doctorDetails, setDoctorDetails] = useState({
    name: "",
    specialization: "",
  });

  const [appointments, setAppointments] = useState([]);
  const [recentPatients, setRecentPatients] = useState([]);
  const [sortConfig, setSortConfig] = useState({
    key: "date", // Default sorting by date
    direction: "asc", // Default ascending order
  });

  const getAppointmentStatus = (appointmentDate) => {
    const today = moment().startOf("day");
    const appointmentMoment = moment(appointmentDate);

    if (appointmentMoment.isBefore(today)) {
      return "Completed";
    } else if (appointmentMoment.isSame(today, "day")) {
      return "Today's Appointment";
    } else {
      return "Upcoming";
    }
  };

  const sortAppointments = (appointments, config) => {
    const sortedAppointments = [...appointments];
    sortedAppointments.sort((a, b) => {
      if (config.key === "date") {
        const dateA = moment(a.date);
        const dateB = moment(b.date);
        if (config.direction === "asc") {
          return dateA.isBefore(dateB) ? -1 : 1;
        } else {
          return dateA.isBefore(dateB) ? 1 : -1;
        }
      } else if (config.key === "status") {
        if (config.direction === "asc") {
          return a.status.localeCompare(b.status);
        } else {
          return b.status.localeCompare(a.status);
        }
      }
      return 0;
    });
    return sortedAppointments;
  };

  const handleSort = (key) => {
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };

  useEffect(() => {
    const fetchDoctorDetails = async () => {
      try {
        const doctorId = localStorage.getItem("user_id");
        if (!doctorId) {
          setAlertMessage("Doctor ID not found in localStorage.");
          setAlertVariant("danger");
          setShowAlert(true);
   
          return;
        }

        const response = await fetch(`http://localhost:8002/doctor/doctor/id/${doctorId}/`);
        if (!response.ok) {
          setAlertMessage("Failed to fetch doctor details");
          setAlertVariant("danger");
          setShowAlert(true);
   
        }

        const data = await response.json();
        setDoctorDetails({
          name: data.name || "Unknown Doctor",
          specialization: data.specialization || "General",
        });

        const appointmentsResponse = await fetch(`http://localhost:8003/appointments/Doctor/${doctorId}`);
        if (!appointmentsResponse.ok) {
          setAlertMessage("Failed to fetch appointments");
          setAlertVariant("danger");
          setShowAlert(true);
   
        }

        const appointmentData = await appointmentsResponse.json();
        const updatedAppointments = appointmentData.map((appointment) => ({
          ...appointment,
          status: getAppointmentStatus(appointment.date),
        }));

        setAppointments(updatedAppointments);
        setRecentPatients(data.recentPatients || []);
      } catch (error) {
        setAlertMessage("Error fetching doctor details");
        setAlertVariant("danger");
        setShowAlert(true);
 
      }
    };

    fetchDoctorDetails();
  }, []);

  const sortedAppointments = sortAppointments(appointments, sortConfig);

  return (
    <>
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        />
    <div className="container mt-4 doctor-dashboard-container">
      {/* Header */}
      <div className="mb-4">
        <h1 className="doctor-dashboard-heading">Welcome, {doctorDetails.name}</h1>
        <p className="doctor-specialization text-muted">
          Specialization: {doctorDetails.specialization}
        </p>
      </div>

      {/* Appointments Section */}
      <div className="  shadow-sm mb-4  c1">
        <div className="card-header bg-primary text-white">
          <h5 className="text-center">Appointments</h5>
        </div>
        <div className="card-body">
          <table className="table table-hover">
            <thead>
              <tr>
                <th
                  onClick={() => handleSort("date")}
                  style={{ cursor: "pointer" }}
                >
                  Time {sortConfig.key === "date" ? (sortConfig.direction === "asc" ? "↑" : "↓") : ""}
                </th>
                <th
                  onClick={() => handleSort("status")}
                  style={{ cursor: "pointer" }}
                >
                  Status {sortConfig.key === "status" ? (sortConfig.direction === "asc" ? "↑" : "↓") : ""}
                </th>
                <th>Patient</th>
              </tr>
            </thead>
            <tbody>
              {sortedAppointments.map((appointment, index) => (
                <tr key={index}>
                  <td>{moment(appointment.date).format("HH:mm")}</td>
                  <td>
                    <span
                      className={`badge ${
                        appointment.status === "Confirmed"
                          ? "bg-success"
                          : appointment.status === "Completed"
                          ? "bg-secondary"
                          : "bg-warning"
                      }`}
                    >
                      {appointment.status}
                    </span>
                  </td>
                  <td>{appointment.userName}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Patients Section */}
      <div className=" shadow-sm c1">
        <div className="card-header bg-secondary text-white">
          <h5>Recent Patient Activity</h5>
        </div>
        <div className="card-body">
          <ul className="list-group">
            {recentPatients.map((patient, index) => (
              <li
                className="list-group-item d-flex justify-content-between recent-patient-item"
                key={index}
              >
                <span>{patient.name}</span>
                <span className="text-muted">
                  Last Visit: {patient.lastVisit}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
    </>
  );
};

export default DoctorDashboard;
