from django.urls import path
from .views import UserRegistrationView,UserDeletionView

urlpatterns = [
    path('register/', UserRegistrationView.as_view(), name='register'),
    path('register/Delete/', UserDeletionView.as_view(), name='delete'),

]
