from django.db import models
from DoctorService.models import DoctorDetails

class DoctorAvailability(models.Model):
    doctor = models.ForeignKey(DoctorDetails, on_delete=models.CASCADE)  # Linking to DoctorDetails model
    day = models.CharField(max_length=20)  # Monday, Tuesday, etc.
    time_slot = models.CharField(max_length=50)  # Example: "10:00 AM - 12:00 PM"
    status = models.CharField(max_length=20, choices=[('Available', 'Available'), ('Unavailable', 'Unavailable')])

    def __str__(self):
        return f"{self.doctor.username} - {self.day}: {self.time_slot} ({self.status})"
