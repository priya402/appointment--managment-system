import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../css/DoctorCss/ViewAppointments.css";
import CustomAlert from '../CustomeAlert'
const DoctorViewAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editingAppointment, setEditingAppointment] = useState(null);
  const [selectedStatus, setSelectedStatus] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info


  const API_URL = "http://localhost:8003/appointments";

  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        const doctorId = localStorage.getItem("user_id");
        if (!doctorId) {
          setAlertMessage("Doctor ID not found in localStorage");
          setAlertVariant("danger");
          setShowAlert(true);
   
          return;
        }

        const response = await fetch(`${API_URL}/Doctor/${doctorId}`);
        if (!response.ok) {
          setAlertMessage("Failed to fetch appointments");
          setAlertVariant("danger");
          setShowAlert(true);
   
        }

        const data = await response.json();
        setAppointments(data);
      } catch (error) {
        setAlertMessage("Failed to fetch appointments");
        setAlertVariant("danger");
        setShowAlert(true);
 
      } finally {
        setLoading(false);
      }
    };

    fetchAppointments();
  }, []);

  const handleEdit = (appointment) => {
    setEditingAppointment(appointment);
    setSelectedStatus(appointment.status || "Not Completed");
    setSelectedTime(appointment.appointmentTime);
    setShowModal(true);
  };

  const handleCancel = async (id) => {
    try {
      const response = await fetch(`${API_URL}/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "Cancelled" }),
      });

      if (!response.ok) {
        setAlertMessage("Failed to cancel appointment");
        setAlertVariant("danger");
        setShowAlert(true);
 
      }

      const updatedAppointments = appointments.map((appointment) =>
        appointment.id === id ? { ...appointment, status: "Cancelled" } : appointment
      );
      setAppointments(updatedAppointments);
      setAlertMessage("Appointment cancled ");
      setAlertVariant("success");
      setShowAlert(true);

    } catch (error) {
      setAlertMessage("Error cancelling appointment");
      setAlertVariant("danger");
      setShowAlert(true);

    }
  };


  const handleSave = async (id) => {
    try {
      const response = await fetch(`http://localhost:8003/appointments/${id}/status`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          isCompleted: selectedStatus === "Completed",
          status: selectedStatus,
          appointmentTime:selectedTime
        }),
      });
  
      if (!response.ok) {
        setAlertMessage("Failed to update appointment");
        setAlertVariant("danger");
        setShowAlert(true);
 
      }
  
      const updatedAppointment = await response.json();
  
      // Update UI
      const updatedAppointments = appointments.map((appointment) =>
        appointment.id === id ? updatedAppointment : appointment
      );
      setAppointments(updatedAppointments);
      setShowModal(false);
      setAlertMessage("Appointment Saved");
      setAlertVariant("success");
      setShowAlert(true);

    } catch (error) {
      setAlertMessage("Error updating appointment");
      setAlertVariant("danger");
      setShowAlert(true);

    }
  };
  

  const handleViewDetails = (appointment) => {
    setSelectedAppointment(appointment);
    setShowDetailsModal(true);
  };

  const handleCloseDetailsModal = () => {
    setShowDetailsModal(false);
  };

  if (loading) return <p>Loading appointments...</p>;
  if (error) return <p className="text-danger">Error: {error}</p>;

  return (
    <>
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        /> 
    <div className="doctor-view-appointments-container mt-4">
      <div className="doctor-view-header mb-4">
        <h1 className="doctor-view-title">View Appointments</h1>
        <p className="doctor-view-subtitle text-muted">Manage all your appointments. Edit, cancel, or view details.</p>
      </div>

      <div className="card doctor-view-appointments-card shadow-sm">
        <div className="card-header doctor-view-card-header">
          <h5>All Appointments</h5>
        </div>
        <div className="card-body doctor-view-card-body">
          {appointments.length > 0 ? (
            <table className="table doctor-view-appointments-table table-bordered table-hover">
              <thead className="doctor-view-table-header table-light">
                <tr>
                  <th>#</th>
                  <th>Patient</th>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Status</th>
                  <th style={{ width: "30%" }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((appointment) => (
                  <tr key={appointment.id}>
                    <td>{appointment.id}</td>
                    <td>{appointment.userName}</td>
                    <td>{appointment.appointmentDate}</td>
                    <td>{appointment.appointmentTime}</td>
                    <td>
                      <span
                        className={`badge doctor-view-status-badge ${
                          appointment.status === "Completed" ? "bg-success" : appointment.status === "Postponed" ? "bg-warning" : "bg-danger"
                        }`}
                      >
                        {appointment.status || "Not Completed"}
                      </span>
                    </td>
                    <td className="d-flex g-10">
                      <button className="btn btn-sm btn-info doctor-view-button me-2" onClick={() => handleViewDetails(appointment)}>
                        View
                      </button>
                      <button className="btn btn-sm btn-warning doctor-view-button me-2" onClick={() => handleEdit(appointment)}>
                        Edit
                      </button>
                      <button
                        className="btn btn-sm btn-danger doctor-view-button"
                        onClick={() => handleCancel(appointment.id)}
                        disabled={appointment.status === "Cancelled"}
                      >
                        Cancel
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="text-muted">No appointments found.</p>
          )}
        </div>
      </div>

      {showDetailsModal && selectedAppointment && (
  <div className="modal fade show" style={{ display: "block" }} tabIndex="-1">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header gap-5">
          <h5 className="modal-title">Appointment Details</h5>
          <button
            type="button"
            className="btn-close"
            onClick={() => setShowDetailsModal(false)}
          ></button>
        </div>
        <div className="modal-body">
          <p><strong>Patient Name:</strong> {selectedAppointment.userName}</p>
          <p><strong>Date:</strong> {selectedAppointment.appointmentDate}</p>
          <p><strong>Time:</strong> {selectedAppointment.appointmentTime}</p>
          <p><strong>Status:</strong> {selectedAppointment.status}</p>
          {/* Add more details if needed */}
        </div>
        <div className="modal-footer">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => setShowDetailsModal(false)}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  </div>
)}

    </div>
    </>
  );
};

export default DoctorViewAppointments;
