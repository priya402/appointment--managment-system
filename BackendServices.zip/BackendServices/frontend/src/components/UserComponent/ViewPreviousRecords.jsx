import React, { useState, useEffect, useRef } from "react";
import "../../css/UserCss/viewPreviousRecords.css";
import CustomAlert from '../CustomeAlert'
const ViewPreviousRecords = () => {
  const [medicalRecords, setMedicalRecords] = useState([]);
  const [selectedReport, setSelectedReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const userId = localStorage.getItem("user_id");
  const hasFetched = useRef(false); // Prevent duplicate requests
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
 
 

  useEffect(() => {
    const fetchRecords = async () => {
      if (hasFetched.current || !userId) return; // Avoid duplicate fetch
      hasFetched.current = true; // Mark as fetched

      try {
        const response = await fetch(`http://localhost:8004/reports/user/${userId}`);
        if (!response.ok) {
          setAlertMessage("Failed to fetch medical records");
          setAlertVariant("danger");
          setShowAlert(true);
   
        }

        const data = await response.json();
        setAlertMessage("Reports found");
        setAlertVariant("success");
        setShowAlert(true);
 
        setMedicalRecords(data);
      } catch (error) {
        
        setAlertMessage("Unable to load records. Please try again later.");
        setAlertVariant("danger");
        setShowAlert(true);
 
      } finally {
        setLoading(false);
      }
    };

    fetchRecords();
  }, [userId]);

  const downloadBase64File = (base64Data, fileName) => {
    const link = document.createElement("a");
  
    // Infer the file type (optional: set mime-type if known)
    const mimeType = "image/png"; // or image/jpeg, application/pdf etc.
    const fileExtension = fileName.split('.').pop() || 'png'; // fallback to png
  
    link.href = `data:${mimeType};base64,${base64Data}`;
    link.download = fileName || `report.${fileExtension}`;
    link.click();
  };
  
  const handleViewReport = (record) => {
    setSelectedReport(record);
  };
  return (
    <>
      <CustomAlert
        show={showAlert}
        message={alertMessage}
        variant={alertVariant}
        onClose={() => setShowAlert(false)}
      />
      <div className="view-previous-records">
        <h2>View Previous Medical Records</h2>
        {loading ? (
          <p>Loading records...</p>
        ) : selectedReport ? (
          <div className="report-details card">
            <h3>Report Details</h3>
            <p><strong>Uploaded By:</strong> {selectedReport.uploadedBy}</p>
            <p><strong>Uploader Name:</strong> {selectedReport.uploaderName}</p>
            <p><strong>Date Uploaded:</strong> {selectedReport.dateUploaded}</p>
            <p><strong>Report Name:</strong> {selectedReport.reportName}</p>
            <button
              className="download-btn"
              onClick={() => downloadBase64File(selectedReport.reportFile, selectedReport.reportName)}
            >
              Download Report
            </button>
            <button className="back-btn" onClick={() => setSelectedReport(null)}>
              Back to Records
            </button>
          </div>
        ) : (
          <div className="records-card-container">
            {medicalRecords.length === 0 ? (
              <p>No medical records available.</p>
            ) : (
              medicalRecords.map((record) => (
                <div key={record.id} className="record-card card">
                  <p><strong>Uploaded By:</strong> {record.uploadedBy}</p>
                  <p><strong>Uploader Name:</strong> {record.uploaderName}</p>
                  <p><strong>Date Uploaded:</strong> {record.dateUploaded}</p>
                  <p><strong>Report Name:</strong> {record.reportName}</p>
                  <button
                    className="view-btn"
                    onClick={() => handleViewReport(record)}
                  >
                    View Report
                  </button>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </>
  );
  
};

export default ViewPreviousRecords;
