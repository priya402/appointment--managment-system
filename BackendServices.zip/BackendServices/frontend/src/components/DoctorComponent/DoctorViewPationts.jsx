import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../css/DoctorCss/DoctorViewPatients.css"; // Custom CSS file for styling
import CustomAlert from '../CustomeAlert'
const DoctorViewPatients = () => {
  const [patients, setPatients] = useState([]);
  const [completedAppointments, setCompletedAppointments] = useState([]);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
  const [selectedPatientId, setSelectedPatientId] = useState(null); // For viewing records
  const [medicalRecords, setMedicalRecords] = useState([]);

  useEffect(() => {
    const fetchPatientData = async () => {
      try {
        // Get doctor ID from localStorage
        const doctorId = localStorage.getItem("user_id");
        if (!doctorId) {
        
          setAlertMessage("Doctor ID not found in localStorage.");
          setAlertVariant("danger");
          setShowAlert(true);
   
          return;
        }

        // Fetch the doctor's appointments
        const appointmentsResponse = await fetch(
          `http://localhost:8003/appointments/Doctor/${doctorId}`
        );
        if (!appointmentsResponse.ok) {
          setAlertMessage("Failed to fetch appointments");
          setAlertVariant("danger");
          setShowAlert(true);
   
        }

        const appointmentData = await appointmentsResponse.json();

        // Filter completed appointments
        const completed = appointmentData.filter(
          (appointment) => appointment.status === "Completed"
        );
        setCompletedAppointments(completed);

        // Get patient details for the completed appointments
        const patientPromises = completed.map((appointment) =>
          fetch(`http://localhost:8002/pationt/patientsDetails/id/${appointment.userId}/`)
        );

        const patientResponses = await Promise.all(patientPromises);
        const patientData = await Promise.all(
          patientResponses.map((response) => response.json())
        );

        // Set the patient data
        setPatients(patientData);
        setAlertMessage("All data found");
        setAlertVariant("success");
        setShowAlert(true);
 
      } catch (error) {
        setAlertMessage("Error fetching patient details");
        setAlertVariant("danger");
        setShowAlert(true);
 
      }
    };

    fetchPatientData();
  }, []);


  const handleViewRecords = async (patientId) => {
    try {
      setSelectedPatientId(patientId);
      const response = await fetch(
        `http://localhost:8004/reports/user/${patientId}` // Replace with actual host
      );
      if (!response.ok) {
        setAlertMessage("Failed to fetch medical records");
        setAlertVariant("danger");
        setShowAlert(true);
        return;
      }
      const records = await response.json();
      setMedicalRecords(records);
    } catch (error) {
      setAlertMessage("Error fetching records");
      setAlertVariant("danger");
      setShowAlert(true);
    }
  };


  return (
    <>
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        /> 
 
    <div className="container mt-4 view-patients">
      {/* Header */}
      <div className="mb-4">
        <h1 className="display-5 card-header ">View Patients</h1>
        <p className="text-muted">List of patients with completed appointments</p>
      </div>

      {/* Patients Table */}
      <div className="card shadow-sm">
        <div className="card-header bg-primary text-white">
          <h5>Completed Appointment Records</h5>
        </div>
        <div className="card-body">
          <table className="table table-hover">
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Contact</th>
                <th>Medical History</th>
              </tr>
            </thead>
            <tbody>
              {patients.map((patient, index) => (
                <tr key={patient.patient_id}>
                  <td>{index + 1}</td>
                  <td>{patient.name}</td>
                  <td>{patient.age}</td>
                  <td>{patient.gender}</td>
                  <td>{patient.phone}</td>
                  <td>
                      <button
                        className="btn btn-outline-info btn-sm"
                        onClick={() => handleViewRecords(patient.patient_id)}
                      >
                        View Records
                      </button></td>       
                               </tr>
              ))}
            </tbody>
          </table>
          {selectedPatientId && medicalRecords.length > 0 && (
              <div className="mt-4">
                <h5>Medical Records for Patient ID: {selectedPatientId}</h5>
                {medicalRecords.map((record, i) => (
                  <div className="card mb-2" key={i}>
                    <div className="card-body">
                      <h6 className="card-title">{record.title}</h6>
                      <p className="card-text">{record.description}</p>
                      <p className="text-muted">
                        <small>Date: {record.date} | Doctor: {record.doctorName}</small>
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
        </div>
      </div>
    </div>
    </>
  );
};

export default DoctorViewPatients;
