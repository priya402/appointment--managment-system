from django.db import models

from django.db import models

class DoctorDetails(models.Model):
    name = models.CharField(max_length=255)
    specialization = models.CharField(max_length=255)
    contact = models.CharField(max_length=15)
    email = models.EmailField(unique=True)
    address = models.TextField()
    qualifications = models.TextField()
    experience = models.IntegerField()  # Number of years of experience
    doctor_number = models.CharField(max_length=20, unique=True)
    emergency_contact = models.CharField(max_length=15)
    aadhar_number = models.CharField(max_length=12, unique=True)
    image = models.TextField(blank=True, null=True)  # Base64 encoded doctor image
    aadhar_image = models.TextField(blank=True, null=True)  # Base64 encoded Aadhar image
    reg_id = models.CharField(max_length=255, null=True, blank=True)  # MongoDB ID field
    hos_id= models.CharField(max_length=255, null=True, blank=True)
    class Meta:
        db_table = 'DoctorDetails'
