import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BsFillCalendarCheckFill, BsFillClockFill } from 'react-icons/bs';
import '../../css/ViewAppointments.css';
import img from "../../assets/imgs.webp";
import CustomAlert from '../CustomeAlert'
const ViewAppointments = () => {
    const [appointments, setAppointments] = useState([]);
    const [selectedAppointment, setSelectedAppointment] = useState(null);
    const [newDate, setNewDate] = useState("");
    const [newTime, setNewTime] = useState("");
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
  

    // Fetch appointments from backend
    useEffect(() => {
        axios.get("http://localhost:8003/appointments/")
            .then(response => {
                if (response.data.length === 0) {
                    setAppointments([]);
                    setAlertMessage("Not found data");
                    setAlertVariant("danger");
                    setShowAlert(true);
             
                } else {
                    setAppointments(response.data);
                    setAlertMessage("Appointment founds");
                    setAlertVariant("success");
                    setShowAlert(true);
             
                }
            })
            .catch(error => console.error("Error fetching appointments:", error));
    }, []);

    const handleView = (appointment) => {
        setSelectedAppointment(appointment);
        setNewDate(appointment.appointmentDate);
        setNewTime(appointment.appointmentTime);
    };

    const handleClose = () => {
        setSelectedAppointment(null);
    };

    const handleCancel = async (appointmentId) => {
        if (!window.confirm("Are you sure you want to cancel this appointment?")) return;

        try {
            await axios.delete(`http://localhost:8003/appointments/${appointmentId}`);
            setAppointments(appointments.filter(appointment => appointment.id !== appointmentId));
            setAlertMessage("Appointment Canceled successfully");
            setAlertVariant("danger");
            setShowAlert(true);
     
        } catch (error) {
            console.error("Error canceling appointment:", error);
            setAlertMessage("Failed to cancle appointment");
            setAlertVariant("danger");
            setShowAlert(true);
     
        }
    };

    const handleReschedule = async () => {
        if (!selectedAppointment) return;
        
        try {
            const updatedAppointment = {
                ...selectedAppointment,
                appointmentDate: newDate,
                appointmentTime: newTime,
            };

            await axios.put(`http://localhost:8003/appointments/update/${selectedAppointment.id}`, updatedAppointment);

            setAppointments(appointments.map(appointment =>
                appointment.id === selectedAppointment.id ? updatedAppointment : appointment
            ));

            setAlertMessage("Appointment reschudeled successfully");
            setAlertVariant("success");
            setShowAlert(true);
     
            setSelectedAppointment(null);
        } catch (error) {
            setAlertMessage("Failed to reschedule appointment");
            setAlertVariant("danger");
            setShowAlert(true);
     
        }
    };

    return (
        <>
         <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        /> 
        <main className="appointments-container">
            <div className="row">
                <div className="col-12">
                    <h3 className="appointments-title">View All Appointments</h3>
                </div>
            </div>

            {/* Show message if there are no appointments */}
            {appointments.length === 0 && (
                <div className="row">
                    <div className="col-12">
                        <p>No appointments available at the moment.</p>
                    </div>
                </div>
            )}

            {selectedAppointment ? (
                // Single Appointment View
                <div className="row mt-4">
                    <div className="col-md-6 offset-md-3">
                        <div className="card appointment-card expanded">
                            <div className="card-body">
                                <div className="appointment-header">
                                    <div className="patient-image">
                                        <img src={selectedAppointment.image || img} alt={selectedAppointment.userName} className="img-fluid" />
                                    </div>
                                    <div className="patient-infos">
                                        <h5>{selectedAppointment.userName}</h5>
                                        <p>Status: {selectedAppointment.status}</p>
                                    </div>
                                </div>
                                <div className="appointment-details">
                                    <p><BsFillCalendarCheckFill /> Date: 
                                        <input 
                                            type="date" 
                                            className="form-control"
                                            value={newDate}
                                            onChange={(e) => setNewDate(e.target.value)}
                                        />
                                    </p>
                                    <p><BsFillClockFill /> Time: 
                                        <input 
                                            type="time" 
                                            className="form-control"
                                            value={newTime}
                                            onChange={(e) => setNewTime(e.target.value)}
                                        />
                                    </p>
                                    <p>Symptoms: {selectedAppointment.symptoms}</p>
                                    <p>Communication Mode: {selectedAppointment.communicationMode}</p>
                                </div>
                                <div className="appointment-actions">
                                    <button className="btn btn-close" onClick={handleClose}>Close</button>
                                    <button className="btn btn-reschedule" onClick={handleReschedule}>Reschedule</button>
                                    <button className="btn btn-cancel" onClick={() => handleCancel(selectedAppointment.id)}>Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                // List View
                <div className="row mt-4">
                    {appointments.map((appointment) => (
                        <div key={appointment.id} className="col-md-3 col-sm-6">
                            <div className="card appointment-card">
                                <div className="card-body">
                                    <div className="appointment-header">
                                        <div className="patient-image">
                                            <img src={appointment.image || img} alt={appointment.userName} className="img-fluid" />
                                        </div>
                                        <div className="row">
                                            <div className="patient-infos col-12">
                                                <h5>{appointment.userName}</h5>
                                            </div>
                                            <div className="col-12">
                                                <p>{appointment.status}</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="appointment-details">
                                        <p><BsFillCalendarCheckFill /> {appointment.appointmentDate}</p>
                                        <p><BsFillClockFill /> {appointment.appointmentTime}</p>
                                    </div>
                                    <div className="appointment-actions">
                                        <button className="btn btn-view" onClick={() => handleView(appointment)}>View</button>
                                        <button className="btn btn-cancel" onClick={() => handleCancel(appointment.id)}>Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </main>
        </>
    );
};

export default ViewAppointments;
