from django.urls import path
from .views import LoginOTPView,AppointmentConfirmationView,AppointmentReminderView,CustomMessageView,RegistrationOTPView

urlpatterns = [
    path('appointmentConfirmation/', AppointmentConfirmationView.as_view(), name='appointmentConfirmation'),
    path('appointmentReminder/', AppointmentReminderView.as_view(), name='appointmentReminder'),
    path('CustomMessage/', CustomMessageView.as_view(), name='CustomMessage'),
    path('LoginOtp/', LoginOTPView.as_view(), name='LoginOtp'),
    path('RegestrationOtp/', RegistrationOTPView.as_view(), name='RegestrationOtp'),


]
