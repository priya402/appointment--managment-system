import requests
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import DoctorDetails
from .serializer import DoctorSerialiser

class DoctorDetailsList(APIView):
    """
    List all doctors or create a new doctor.
    """

    def get(self, request):
        doctors = DoctorDetails.objects.all()
        serializer = DoctorSerialiser(doctors, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = DoctorSerialiser(data=request.data)
        if serializer.is_valid():
            # Save doctor details in MySQL
            doctor = serializer.save()

            # Prepare data to send to registration service
            registration_data = {
                "email": doctor.email,
                "name": doctor.name,
                "phone_number": doctor.contact,  # Ensure this matches the field name in your model
                # Assuming "doctor" role for registration
                "action": "doctor_register"
            }

            # Send data to registration service
            registration_service_url = "http://localhost:8001/regestration/register/"
            registration_response = requests.post(registration_service_url, json=registration_data)

            if registration_response.status_code == 201:
                # Registration was successful, now get the MongoDB generated _id
                mongo_id = registration_response.json().get('doctor_id')

                if mongo_id:
                    # Update the doctor record in MySQL with MongoDB generated _id
                    doctor.reg_id = mongo_id
                    doctor.save()

                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                else:
                    # If MongoDB ID is not returned, return error
                    return Response({"error": "MongoDB ID not returned from registration service."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            else:
                # Handle failure to register doctor
                return Response({"error": "Failed to register doctor in registration service.","registration_response":registration_response}, status=status.HTTP_400_BAD_REQUEST)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
class DoctorDetailsDetail(APIView):
    """
    Retrieve, update, or delete a doctor based on MongoDB `_id`.
    """

    def get_object_by_id(self, doctor_id):
        try:
            return DoctorDetails.objects.get(reg_id=doctor_id)
        except DoctorDetails.DoesNotExist:
            return None

    def get_object_by_email(self, email):
        try:
            return DoctorDetails.objects.get(email=email)
        except DoctorDetails.DoesNotExist:
            return None

    def get(self, request, identifier):
        doctor = None
        
        # Check if identifier is an email or MongoDB _id
        if "@" in identifier:  # If it's an email
            doctor = self.get_object_by_email(identifier)
        else:  # If it's MongoDB _id
            doctor = self.get_object_by_id(identifier)
        
        if not doctor:
            return Response({"error": "Doctor not found."}, status=status.HTTP_404_NOT_FOUND)
        
        # Serialize the doctor details and return response
        serializer = DoctorSerialiser(doctor)
        return Response(serializer.data)

    def put(self, request, identifier):
        doctor = None

        # Check if identifier is an email or MongoDB _id
        if "@" in identifier:  # If it's an email
            doctor = self.get_object_by_email(identifier)
        else:  # If it's MongoDB _id
            doctor = self.get_object_by_id(identifier)
        
        if not doctor:
            return Response({"error": "Doctor not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = DoctorSerialiser(doctor, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, identifier):
        doctor = None

        # Check if identifier is an email or MongoDB _id
        if "@" in identifier:  # If it's an email
            doctor = self.get_object_by_email(identifier)
        else:  # If it's MongoDB _id
            doctor = self.get_object_by_id(identifier)
        
        if not doctor:
            return Response({"error": "Doctor not found."}, status=status.HTTP_404_NOT_FOUND)

        doctor.delete()
        return Response({"message": "Doctor deleted successfully."}, status=status.HTTP_204_NO_CONTENT)
