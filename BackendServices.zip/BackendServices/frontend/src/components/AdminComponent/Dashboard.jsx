import React, { useEffect, useState } from 'react';
import { 
  BsFillArchiveFill, 
  BsFillBellFill, 
  BsCalendarCheck, 
  BsClock 
} from 'react-icons/bs';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import axios from 'axios';
import '../../css/Dashboard.css';
import CustomAlert from '../CustomeAlert';
function AdminDashboard() {
  const [appointmentData, setAppointmentData] = useState([]);
  const [patientData, setPatientData] = useState([]);
  const [doctorData, setDoctorData] = useState([]);
  const [appointmentStats, setAppointmentStats] = useState({
    scheduled: 0,
    completed: 0,
    pending: 0,
    canceled: 0,
  });
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info


  // API URLs for the services (replace with your actual URLs)
  const appointmentServiceUrl = 'http://localhost:8003/appointments/';
  const patientServiceUrl = 'http://localhost:8002/pationt/patients/get-all/';
  const doctorServiceUrl = 'http://localhost:8002/doctor/doctor/';

  // Fetch data from the backend
  const fetchData = async () => {
    try {
      // Fetching appointment data
      const appointmentResponse = await axios.get(appointmentServiceUrl);
      setAppointmentData(appointmentResponse.data||[]);
  
      // Fetching patient data
      const patientResponse = await axios.get(patientServiceUrl);
      setPatientData(patientResponse.data || []);
  
      // Fetching doctor data
      const doctorResponse = await axios.get(doctorServiceUrl);
      setDoctorData(doctorResponse.data || []);
  
      // Calculating appointment stats (counting statuses)
      let scheduled = 0, completed = 0, pending = 0, canceled = 0;
      
      appointmentData.forEach(appointment => {
        switch (appointment.status) {
          case 'scheduled':
            scheduled++;
            break;
          case 'completed':
            completed++;
            break;
          case 'pending':
            pending++;
            break;
          case 'canceled':
            canceled++;
            break;
          default:
            break;
        }
      });
      
      setAppointmentStats({ scheduled, completed, pending, canceled });

 setAlertMessage("Fetched appointments");
 setAlertVariant("success");
 setShowAlert(true);

    } catch (error) {

 setAlertMessage("Error fetching data"+error);
 setAlertVariant("danger");
 setShowAlert(true);

    }
  };
  

  useEffect(() => {
    fetchData();
  }, []);

  const pieData = [
    { name: 'Completed', value: appointmentStats.completed || 0 },
    { name: 'Pending', value: appointmentStats.pending || 0 },
    { name: 'Canceled', value: appointmentStats.canceled || 0 },
  ];

  const COLORS = ['#2ecc71', '#f39c12', '#e74c3c'];

  return (
    <>
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        /> 
 
    <main className='dashboard-container '>
      <div className='row'>
        <div className='col-12'>
          <h3 className="dashboard-title">Admin Dashboard</h3>
        </div>
      </div>

      {/* Summary Cards */}
      <div className='row mt-4'>
        <div className='col-md-3 col-sm-6'>
          <div className='card dashboard-card'>
            <div className='card-body d-flex justify-content-between align-items-center'>
              <h5>SCHEDULED APPOINTMENTS</h5>
              <BsCalendarCheck className='card_icon' />
            </div>
            <h1 className='text-center card-number'>{appointmentStats.scheduled || 0}</h1>
          </div>
        </div>
        <div className='col-md-3 col-sm-6'>
          <div className='card dashboard-card'>
            <div className='card-body d-flex justify-content-between align-items-center'>
              <h5>COMPLETED APPOINTMENTS</h5>
              <BsClock className='card_icon' />
            </div>
            <h1 className='text-center card-number'>{appointmentStats.completed || 0}</h1>
          </div>
        </div>
        <div className='col-md-3 col-sm-6'>
          <div className='card dashboard-card'>
            <div className='card-body d-flex justify-content-between align-items-center'>
              <h5>PENDING APPOINTMENTS</h5>
              <BsFillBellFill className='card_icon' />
            </div>
            <h1 className='text-center card-number'>{appointmentStats.pending || 0}</h1>
          </div>
        </div>
        <div className='col-md-3 col-sm-6'>
          <div className='card dashboard-card'>
            <div className='card-body d-flex justify-content-between align-items-center'>
              <h5>CANCELED APPOINTMENTS</h5>
              <BsFillArchiveFill className='card_icon' />
            </div>
            <h1 className='text-center card-number'>{appointmentStats.canceled || 0}</h1>
          </div>
        </div>
      </div>

      {/* Role-specific charts */}
      <div className='row mt-5 align-item-center'>
        <div className='col-md-5 col-sm-6'>
          <div className='card'>
            <div className='card-header'>
              <h5>Appointment Stats</h5>
            </div>
            <div className='card-body'>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={appointmentData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="scheduled" fill="#2ecc71" />
                  <Bar dataKey="completed" fill="#3498db" />
                  <Bar dataKey="pending" fill="#f39c12" />
                  <Bar dataKey="canceled" fill="#e74c3c" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className='col-md-5 col-sm-6'>
          <div className='card'>
            <div className='card-header'>
              <h5>Overall Appointment Status</h5>
            </div>
            <div className='card-body'>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    label
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className='col-md-5 col-sm-12 mt-5'>
          <div className='card'>
            <div className='card-header'>
              <h5>Doctor Data</h5>
            </div>
            <div className='card-body'>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={doctorData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="available" fill="#2ecc71" />
                  <Bar dataKey="unavailable" fill="#e74c3c" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className='col-md-5 col-sm-12 mt-5'>
          <div className='card'>
            <div className='card-header'>
              <h5>Patient Data</h5>
            </div>
            <div className='card-body'>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={patientData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    label
                  >
                    <Cell fill="#3498db" />
                    <Cell fill="#f39c12" />
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

    </main>
    </>
  );
}

export default AdminDashboard;
