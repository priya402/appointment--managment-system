from django.urls import path
from .views import PatientCreateView, PatientDetailView,PatientListView

urlpatterns = [
    path('patients/', PatientCreateView.as_view(), name='create-patient'),
    path('patients/get-all/', PatientListView.as_view(), name='create-patient'),
    path('patientsDetails/email/<str:email>/', PatientDetailView.as_view(), name='patient-detail-email'),
    path('patientsDetails/id/<str:patient_id>/', PatientDetailView.as_view(), name='patient-detail-id'),
    path('patientsDetails/update/<str:patient_id>/', PatientDetailView.as_view(), name='patient-update'),


]
