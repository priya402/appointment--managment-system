import React, { useEffect } from 'react';
import { BrowserRouter, Route, Routes ,Navigate} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import './App.css';
import Navbar from './components/Navbar';
import AuthPage from './components/AuthPage'; // Import the AuthPage component
import Dashboard from './components/AdminComponent/Dashboard';
import DoctorCard from './components/AdminComponent/DoctorCard'
import PatientList from './components/AdminComponent/ViewPationt';
import PatientDetails from './components/AdminComponent/PatientDetails';
import AddPationt from './components/AdminComponent/AddPationt';
import ViewAppointments from './components/AdminComponent/ViewAppointment';
import ViewDoctor from './components/AdminComponent/ViewDoctor';
import AddDoctor from './components/AdminComponent/AddDoctor';
import ScheduleAppointment from './components/AdminComponent/ShedulaAppointments';
import SystemSettings from './components/AdminComponent/SystemSetting';
import UserSettings from './components/AdminComponent/UserSettings';
import UserDashboard from './components/UserComponent/UserDashboard';
import BookAppointment from './components/UserComponent/BookAppointment';
import ViewAppointment from './components/UserComponent/ViewAppointment';
import ViewPreviousRecords from './components/UserComponent/ViewPreviousRecords';
import UploadReport from './components/UserComponent/UploadReports';
import ViewProfile from './components/UserComponent/ViewProfile';
import FeedbackForm from './components/UserComponent/FeedBackForm';
import Settings from './components/UserComponent/Setting';
import DoctorDashboard from './components/DoctorComponent/DoctorDashboard';
import DoctorViewPatients from './components/DoctorComponent/DoctorViewPationts';
import AddPatientNotes from './components/DoctorComponent/AddPatientNotes';
import DoctorViewAppointments from './components/DoctorComponent/ViewAppointments';
import DoctorScheduleAppointment from './components/DoctorComponent/ShedualAppointments';
import DoctorAvailability from './components/DoctorComponent/DoctorAvailablity';
import DoctorStatistics from './components/DoctorComponent/DoctorStatistics';
import AboutPage from './components/AboutPage';
import NotesPage from './components/UserComponent/NotesPage';
import ReportPage from './components/ReportPage';

function App() {

  useEffect(() => {
    const savedTheme = localStorage.getItem("selectedTheme") || "light";
    document.body.classList.remove("dark-theme", "light-theme");
    document.body.classList.add(`${savedTheme}-theme`);
  }, []);
  
  const isAuthenticated = localStorage.getItem('auth') === 'true';
  const userRole = localStorage.getItem('role'); // Possible values: 'admin', 'user', 'doctor'

  const getNavbarForRole = () => {
    if (userRole === 'admin') {
      return <Navbar role="admin" />;
    }
    if (userRole === 'user') {
      return <Navbar role="user" />;
    }
    if (userRole === 'doctor') {
      return <Navbar role="doctor" />;
    }
    return null; // No navbar for unauthenticated users
  };

  const redirectToRoleBasedDashboard = () => {
    if (userRole === 'admin') {
      return <Navigate to="/dashboard" replace />;
    }
    if (userRole === 'user') {
      return <Navigate to="/UserDashboard" replace />;
    }
    if (userRole === 'doctor') {
      return <Navigate to="/DoctorDashboard" replace />;
    }
    return <Navigate to="/" replace />;
  };

  return (
    <BrowserRouter>
    {!isAuthenticated ? (
        // Show AuthPage if the user is not authenticated
        <AuthPage />
      ) : (
        <>
      {/* Show the appropriate navbar based on the role */}
      {isAuthenticated && userRole && getNavbarForRole()}
      <div className="main-content-wrapper" >
        <Routes>
          <Route
            path="/"
            element={
              !isAuthenticated || !userRole ? (
                <AuthPage />
              ) : (
                redirectToRoleBasedDashboard()
              )
            }
          />
          {/* Admin Routes */}
          <Route path="/dashboard" element={ isAuthenticated ?<Dashboard />:<AuthPage />} />
          <Route path="/view-doctor" element={ isAuthenticated ?<DoctorCard />:<AuthPage />} />
          <Route path="/view-patient" element={isAuthenticated ?<PatientList />:<AuthPage />} />
          <Route path="/patient/:id" element={isAuthenticated ?<PatientDetails />:<AuthPage />} />
          <Route path="/add-patient" element={isAuthenticated ?<AddPationt />:<AuthPage />} />
          <Route path="/view-appointments" element={isAuthenticated ?<ViewAppointments />:<AuthPage />} />
          <Route path="/schedule-appointments" element={isAuthenticated ?<ScheduleAppointment />:<AuthPage />} />
          <Route path="/doctor/:id" element={isAuthenticated ?<ViewDoctor />:<AuthPage />} />
          <Route path="/add-doctor" element={isAuthenticated ?<AddDoctor />:<AuthPage />} />
          <Route path="/system-settings" element={isAuthenticated ?<SystemSettings />:<AuthPage />} />
          <Route path="/user-settings" element={isAuthenticated ?<UserSettings />:<AuthPage />} />
          {/* User Routes */}
          <Route path="/UserDashboard" element={isAuthenticated ?<UserDashboard />:<AuthPage />} />
          <Route path="/BookAppointment" element={isAuthenticated ?<BookAppointment />:<AuthPage />} />
          <Route path="/ViewAppointment" element={isAuthenticated ?<ViewAppointment />:<AuthPage />} />
          <Route path="/viewPreviousRecords" element={isAuthenticated ?<ViewPreviousRecords />:<AuthPage />} />
          <Route path="/uploadReports" element={isAuthenticated ?<UploadReport />:<AuthPage />} />
          <Route path="/ViewProfile" element={isAuthenticated ?<ViewProfile />:<AuthPage />} />
          <Route path="/FeedBack" element={isAuthenticated ?<FeedbackForm />:<AuthPage />} />
          <Route path="/Notes" element={isAuthenticated ?<NotesPage />:<AuthPage />} />

          {/* Doctor Routes */}
          <Route path="/DoctorDashboard" element={isAuthenticated ?<DoctorDashboard />:<AuthPage />} />
          <Route path="/DoctorViewPationt" element={isAuthenticated ?<DoctorViewPatients />:<AuthPage />} />
          <Route path="/AddPationtNotes" element={isAuthenticated ?<AddPatientNotes />:<AuthPage />} />
          <Route path="/ViewAppointments" element={isAuthenticated ?<DoctorViewAppointments />:<AuthPage />} />
          <Route path="/DoctorShedualAppointments" element={isAuthenticated ?<DoctorScheduleAppointment />:<AuthPage />} />
          <Route path="/DoctorAvailablity" element={isAuthenticated ?<DoctorAvailability />:<AuthPage />} />
          <Route path="/DoctorStatistics" element={isAuthenticated ?<DoctorStatistics />:<AuthPage />} />
          <Route path="/AboutUs" element={isAuthenticated ?<AboutPage />:<AuthPage />} />
          <Route path="/reports" element={isAuthenticated ?<ReportPage />:<AuthPage />} />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
      </>)}
    </BrowserRouter>
  );
}

export default App;
