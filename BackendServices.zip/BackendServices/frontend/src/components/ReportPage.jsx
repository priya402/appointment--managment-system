import React, { useEffect, useState } from "react";
import axios from "axios";
import "../css/ReportPage.css";

const ReportPage = () => {
  const [appointments, setAppointments] = useState([]);
  const [filteredAppointments, setFilteredAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ total: 0, upcoming: 0, completed: 0 });

  // ✅ Get role and user_id from localStorage
  const role = localStorage.getItem("user_role");
  const userId = localStorage.getItem("id");

  const appointmentServiceUrl = "http://localhost:8003/appointments/"; // change as needed

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    try {
      const res = await axios.get(appointmentServiceUrl);
      const allAppointments = res.data || [];

      let userSpecificAppointments = [];

      if (role === "user") {
        userSpecificAppointments = allAppointments.filter(
          (apt) => apt.user_id === userId
        );
      } else if (role === "doctor") {
        userSpecificAppointments = allAppointments.filter(
          (apt) => apt.doctor_id === userId
        );
      } else {
        userSpecificAppointments = allAppointments;
      }

      const completed = userSpecificAppointments.filter((apt) => apt.status === "completed").length;
      const upcoming = userSpecificAppointments.filter((apt) => apt.status === "scheduled" || apt.status === "pending").length;

      setAppointments(userSpecificAppointments);
      setStats({
        total: userSpecificAppointments.length,
        upcoming,
        completed,
      });

      setFilteredAppointments(userSpecificAppointments);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching appointments:", error);
      setLoading(false);
    }
  };

  return (
    <div className="report-container">
      <h2>{role === "admin" ? "System Reports" : "Appointment History"}</h2>

      <div className="stats-box">
        <div className="stat-card">Total Appointments: {stats.total}</div>
        <div className="stat-card">Upcoming: {stats.upcoming}</div>
        <div className="stat-card">Completed: {stats.completed}</div>
      </div>

      <div className="appointment-table">
        <h3>Detailed Report</h3>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Appointment ID</th>
                <th>User</th>
                <th>Doctor</th>
                <th>Date</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredAppointments.map((apt) => (
                <tr key={apt._id}>
                  <td>{apt._id}</td>
                  <td>{apt.user_name || "N/A"}</td>
                  <td>{apt.doctor_name || "N/A"}</td>
                  <td>{new Date(apt.date).toLocaleString()}</td>
                  <td>{apt.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default ReportPage;
