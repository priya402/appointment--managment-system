import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import "../../css/ViewDoctor.css"; // Modify this CSS for styling
import CustomAlert from "../CustomeAlert";
const ViewDoctor = () => {
  const { id } = useParams(); // Get the doctor ID from the URL
  const navigate = useNavigate(); // To navigate after actions

  // State for doctor details and loading state
  const [doctor, setDoctor] = useState(null);
  const [editableDoctor, setEditableDoctor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [imageInputVisible, setImageInputVisible] = useState(false); // To toggle image input
  const [imageBase64, setImageBase64] = useState(null); // To store base64 image
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info


  // Fetch doctor details on component mount
  useEffect(() => {
    const fetchDoctorDetails = async () => {
      try {
        const response = await axios.get(`http://localhost:8002/doctor/doctor/id/${id}/`);
        setDoctor(response.data);
        setEditableDoctor(response.data); // Initialize editable doctor details
        setImageBase64(response.data.image); // Set the initial image base64 if available
        setAlertMessage("Doctor data fetched");
        setAlertVariant("success");
        setShowAlert(true);
 
      } catch (error) {
        setAlertMessage("error fetching doctor details");
        setAlertVariant("danger");
        setShowAlert(true);
 
      } finally {
        setLoading(false);
      }
    };
    fetchDoctorDetails();
  }, [id]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!doctor) {
    return <div>Doctor not found</div>;
  }

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditableDoctor((prev) => ({ ...prev, [name]: value }));
  };

  // Handle image file change (convert to base64)
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageBase64(reader.result); // Set the base64 string of the image
        setEditableDoctor((prev) => ({ ...prev, image: reader.result })); // Update the editable doctor state
      };
      reader.readAsDataURL(file);
    }
  };

  // Toggle image input visibility
  const handleImageClick = () => {
    setImageInputVisible(!imageInputVisible);
  };

  // Handle Update action
  const handleUpdate = async () => {
    try {
      const response = await axios.put(`http://localhost:8002/doctor/doctor/id/${id}/`, editableDoctor);
      setDoctor(response.data); // Update local doctor data
      setAlertMessage("Detaild Upadted");
      setAlertVariant("success");
      setShowAlert(true);

    } catch (error) {
      setAlertMessage("Failed to update");
      setAlertVariant("danger");
      setShowAlert(true);

    }
  };

  // Handle Delete action
  const handleDelete = async () => {
    const confirmDelete = window.confirm("Are you sure you want to delete this doctor?");
    if (confirmDelete) {
      try {
        await axios.delete(`http://localhost:8002/doctor/doctor/id/${id}/`);
        setAlertMessage("delete success");
        setAlertVariant("success");
        setShowAlert(true);
 
        navigate("/doctors"); // Redirect to the doctors list page after deletion
      } catch (error) {
        setAlertMessage("Failed to delete");
        setAlertVariant("danger");
        setShowAlert(true);
 
      }
    }
  };

  return (
    <>
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        /> 
    <div className="doctor-details-container">
      <header className="header">
        <h2>Doctor Details</h2>
      </header>
      <div className="doctor-details-card">
        <div className="doctor-details-header">
          <div className="doctor-image-container" onClick={handleImageClick}>
            <img
              src={imageBase64} // Show default image or the base64 image
              alt="Doctor"
              className="doctor-image-large"
            />
          </div>
          {imageInputVisible && (
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="image-input"
            />
          )}
          <div className="doctor-name">
            <input
              type="text"
              name="name"
              value={editableDoctor.name}
              onChange={handleInputChange}
              className="editable-input doctor-name-input"
            />
          </div>
        </div>
        <div className="doctor-info">
          {[
            { label: "Specialization", name: "specialization" },
            { label: "Contact", name: "contact" },
            { label: "Email", name: "email" },
            { label: "Address", name: "address" },
            { label: "Qualifications", name: "qualifications" },
            { label: "Experience (Years)", name: "experience" },
            { label: "Doctor Number", name: "doctor_number" },
            { label: "Emergency Contact", name: "emergency_contact" },
            { label: "Aadhar Number", name: "aadhar_number" },
            { label: "Aadhar Image", name: "aadhar_image" },
          ].map(({ label, name }) => (
            <div key={name} className="doctor-info-item">
              <span>{label}:</span>
              <input
                type="text"
                name={name}
                value={editableDoctor[name] || ''}
                onChange={handleInputChange}
                className="editable-input"
              />
            </div>
          ))}
        </div>
        <div className="action-buttons">
          <button className="btn update-button " onClick={handleUpdate}>Update</button>
          <button className="btn delete-button" onClick={handleDelete}>Delete</button>
          <button className="btn back-button" onClick={() => navigate("/view-doctor")}>Back</button>
        </div>
      </div>
    </div>
    </>
  );
};

export default ViewDoctor;
