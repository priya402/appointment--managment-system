import React, { useState } from 'react';
import '../../css/UserCss/UserSetting.css';

const Settings = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    document.body.classList.toggle('dark-mode', !isDarkMode);
  };

  const handleSave = (e) => {
    e.preventDefault();
    // Save settings logic (could send data to backend here)
    console.log({ isDarkMode, emailNotifications, smsNotifications });
  };

  return (
    <div className="user-settings-container">
      <h2>User Settings</h2>
      <p className="settings-description">
        Update your preferences and account settings to customize your experience.
      </p>
      <form onSubmit={handleSave} className="user-settings-form">
        {/* Theme Section */}
        <div className="form-section">
          <h3>Theme Settings</h3>
          <div className="form-group">
            <label htmlFor="theme-toggle" className="theme-label">
              <input
                type="checkbox"
                id="theme-toggle"
                checked={isDarkMode}
                onChange={toggleTheme}
              />
              Enable Dark Mode
            </label>
          </div>
        </div>

        {/* Notification Settings */}
        <div className="form-section">
          <h3>Notification Preferences</h3>
          <div className="form-group">
            <label htmlFor="email-notifications">
              <input
                type="checkbox"
                id="email-notifications"
                checked={emailNotifications}
                onChange={() => setEmailNotifications(!emailNotifications)}
              />
              Email Notifications
            </label>
          </div>
          <div className="form-group">
            <label htmlFor="sms-notifications">
              <input
                type="checkbox"
                id="sms-notifications"
                checked={smsNotifications}
                onChange={() => setSmsNotifications(!smsNotifications)}
              />
              SMS Notifications
            </label>
          </div>
        </div>

        {/* Save Button */}
        <div className="form-actions">
          <button type="submit" className="save-btn">
            Save Changes
          </button>
        </div>
      </form>
    </div>
  );
};

export default Settings;
