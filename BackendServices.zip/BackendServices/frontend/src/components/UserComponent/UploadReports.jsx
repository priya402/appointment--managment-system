import React, { useState } from "react";
import "../../css/UserCss/UploadReport.css";
import CustomAlert from '../CustomeAlert'
const UploadReport = () => {
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
 
  const [formData, setFormData] = useState({
    uploadedBy: "",
    uploaderName: "",
    dateUploaded: "",
    reportName: "",
    reportFile: null,
    hospitalName: "",
    doctorName: "",
    reportType: "",
    description: "",
    userId:localStorage.getItem("user_id")
  });

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;
  
    if (type === "file") {
      const file = files[0];
  
      if (file) {
        const maxSize = 1 * 1024 * 1024; // 1MB
  
        if (file.size > maxSize) {
          alert("File size must be less than or equal to 1MB.");
          e.target.value = ""; // Reset file input
          return;
        }
  
        setFormData({ ...formData, [name]: file });
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };
  

  const handleFileConversion = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result.split(",")[1]); // Extract Base64 string
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Convert the file to Base64
    const base64File = formData.reportFile ? await handleFileConversion(formData.reportFile) : null;

    // Create the report data object to send to the backend
    const reportData = {
      uploadedBy: formData.uploadedBy,
      uploaderName: formData.uploaderName,
      dateUploaded: formData.dateUploaded,
      reportName: formData.reportName,
      reportFile: base64File,
      hospitalName: formData.hospitalName,
      doctorName: formData.doctorName,
      reportType: formData.reportType,
      description: formData.description,
      userId:localStorage.getItem("user_id")

    };

    try {
      const response = await fetch("http://localhost:8004/reports/upload", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(reportData),
      });

      if (response.ok) {
    
        setAlertMessage("Report uploaded successfully!");
        setAlertVariant("success");
        setShowAlert(true);
 
        setFormData({
          uploadedBy: "",
          uploaderName: "",
          dateUploaded: "",
          reportName: "",
          reportFile: null,
          hospitalName: "",
          doctorName: "",
          reportType: "",
          description: "",
          userId:localStorage.getItem("user_id")

        });
      } else {
        setAlertMessage("Failed to upload the report.");
        setAlertVariant("danger");
        setShowAlert(true);
 
      }
    } catch (error) {
      setAlertMessage("Error at server side ");
      setAlertVariant("danger");
      setShowAlert(true);
    }
  };

  return (
    <>
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        />
    <div className="upload-report">
      <h2>Upload Medical Report</h2>
      <form onSubmit={handleSubmit} className="upload-form">
        <div className="form-row">
          <div className="form-group ">
            <label>Uploaded By</label>
            <select
              name="uploadedBy"
              value={formData.uploadedBy}
              onChange={handleChange}
              required
            >
              <option value="" disabled>
                Select
              </option>
              <option value="Doctor">Doctor</option>
              <option value="User">User</option>
            </select>
          </div>
          <div className="form-group ">
            <label>Uploader Name</label>
            <input
              type="text"
              name="uploaderName"
              value={formData.uploaderName}
              onChange={handleChange}
              placeholder="Enter uploader's name"
              required
            />
          </div>
          
        </div>

        <div className="form-row">
        <div className="form-group ">
            <label>Date Uploaded</label>
            <input
              type="date"
              name="dateUploaded"
              value={formData.dateUploaded}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Report Name</label>
            <input
              type="text"
              name="reportName"
              value={formData.reportName}
              onChange={handleChange}
              placeholder="Enter report name"
              required
            />
          </div>
          </div>
          <div className="form-row">

          <div className="form-group">
            <label>Hospital Name</label>
            <input
              type="text"
              name="hospitalName"
              value={formData.hospitalName}
              onChange={handleChange}
              placeholder="Enter hospital name"
            />
          </div>
          <div className="form-group">
            <label>Doctor Name</label>
            <input
              type="text"
              name="doctorName"
              value={formData.doctorName}
              onChange={handleChange}
              placeholder="Enter doctor name"
            />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Report Type</label>
            <select
              name="reportType"
              value={formData.reportType}
              onChange={handleChange}
              required
            >
              <option value="" disabled>
                Select
              </option>
              <option value="Blood Test">Blood Test</option>
              <option value="X-Ray">X-Ray</option>
              <option value="MRI">MRI</option>
              <option value="Prescription">Prescription</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div className="form-group">
            <label>Upload Report</label>
            <input
              type="file"
              name="reportFile"
              accept=".pdf,.doc,.docx,.jpg,.png"
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group full-width">
            <label>Description</label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Provide a brief description of the report"
              rows="3"
            ></textarea>
          </div>
        </div>

        <button type="submit" className="submit-btn">
          Upload Report
        </button>
      </form>
    </div>
    </>
  );
};

export default UploadReport;
