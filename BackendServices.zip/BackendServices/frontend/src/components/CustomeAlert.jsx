import React from 'react';
import '../css/CustomAlert.css';

const CustomAlert = ({ show, message, variant, onClose }) => {
  if (!show) return null;

  return (
    <div className={`custom-alert ${variant} show`}>
      <div className="alert-message">{message}</div>
      <button className="close-btn" onClick={onClose}>×</button>
    </div>
  );
};

export default CustomAlert;
