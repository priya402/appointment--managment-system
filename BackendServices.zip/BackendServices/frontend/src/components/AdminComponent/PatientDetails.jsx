import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "../../css/PatientDetails.css";
import CustomAlert from "../CustomeAlert";

const PatientDetails = () => {
  const { id } = useParams(); // Get patient ID from URL
  const navigate = useNavigate();
  const [patient, setPatient] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info

  const [editablePatient, setEditablePatient] = useState({
    name: "",
    email: "",
    phone: "",
    dob: "",
    gender: "",
    address_line1: "",
    city: "",
    state: "",
    zip_code: "",
    profile_image: "",
  });

  useEffect(() => {
    const fetchPatient = async () => {
      try {
        const response = await fetch(`http://localhost:8002/pationt/patientsDetails/id/${id}/`);
        if (!response.ok) {
           setAlertMessage("Patient not found");
        setAlertVariant("danger");
        setShowAlert(true);
 
        }
        const data = await response.json();

        // Ensure the profile image is correctly set from base64 encoded string
        const updatedData = {
          ...data,
          profile_image: data.profile_image || "",
        };

        setPatient(updatedData);
        setEditablePatient(updatedData);
         setAlertMessage("Patient details");
        setAlertVariant("success");
        setShowAlert(true);
 
      } catch (err) {
         setAlertMessage("Error to find details");
        setAlertVariant("danger");
        setShowAlert(true);
 
      } finally {
        setLoading(false);
      }
    };

    fetchPatient();
  }, [id]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditablePatient((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditablePatient((prev) => ({
          ...prev,
          profile_image: reader.result, // Store file as a base64 image
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpdate = async () => {
    try {
      const response = await fetch(`http://localhost:8002/pationt/patientsDetails/id/${id}/`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(editablePatient),
      });

      if (!response.ok) {
         setAlertMessage("Failed to update patient details");
        setAlertVariant("danger");
        setShowAlert(true);
 
      }

      const updatedPatient = await response.json();
      setPatient(updatedPatient);
       setAlertMessage("Patient details updtae successfully");
        setAlertVariant("success");
        setShowAlert(true);
 
    } catch (err) {
       setAlertMessage("error to save data");
        setAlertVariant("danger");
        setShowAlert(true);
 
    }
  };

  const handleDelete = async () => {
    const confirmDelete = window.confirm("Are you sure you want to delete this patient?");
    if (confirmDelete) {
      try {
        const response = await fetch(`http://3.108.112.64:8002/pationt/patientsDetails/id/${id}/`, {
          method: "DELETE",
        });

        if (!response.ok) {
           setAlertMessage("Failed to delete patient");
        setAlertVariant("danger");
        setShowAlert(true);
 
        }

        setAlertMessage("Patient deleted successfully");
        setAlertVariant("danger");
        setShowAlert(true);
 
        navigate("/patients"); // Redirect to the patients list
      } catch (err) {
         setAlertMessage("error at the end");
        setAlertVariant("danger");
        setShowAlert(true);
 
      }
    }
  };

  if (loading) return <div>Loading patient details...</div>;
  if (!patient) return <div>Patient not found</div>;

  return (
    <>
     <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        /> 
    <div className="patient-details-container">
      <header className="header">
        <h2>Patient Details</h2>
      </header>
      <div className="patient-details-card">
        <div className="patient-details-header">
          <div className="patient-image-container">
            {editablePatient.profile_image ? (
              <img src={editablePatient.profile_image} alt="Patient" className="patient-image-large" />
            ) : (
              <p>No image available</p>
            )}
          </div>
          <div className="patient-name">
            <input
              type="text"
              name="name"
              value={editablePatient.name || ""}
              onChange={handleInputChange}
              className="editable-input patient-name-input"
            />
          </div>
        </div>

        {/* Patient Info */}
        <div className="patient-info">
          {[
            { label: "Phone", name: "phone" },
            { label: "Email", name: "email" },
            { label: "Date of Birth", name: "dob" },
            { label: "Gender", name: "gender" },
            { label: "Address", name: "address_line1" },
            { label: "City", name: "city" },
            { label: "State", name: "state" },
            { label: "Zip Code", name: "zip_code" },
          ].map(({ label, name }) => (
            <div key={name} className="patient-info-item">
              <span>{label}:</span>
              <input
                type="text"
                name={name}
                value={editablePatient[name] || ""}
                onChange={handleInputChange}
                className="editable-input"
              />
            </div>
          ))}
        </div>

        {/* Profile Image Upload */}
        <div className="profile-image-upload">
          <label htmlFor="profileImage">Upload Profile Image</label>
          <input
            type="file"
            id="profileImage"
            onChange={handleFileUpload}
            className="editable-input"
          />
        </div>

        {/* Action Buttons */}
        <div className="action-buttons">
          <button className="btn update-button" onClick={handleUpdate}>Update</button>
          <button className="btn delete-button" onClick={handleDelete}>Delete</button>
          <button className="btn back-button" onClick={() => navigate(-1)}>Back</button>
        </div>
      </div>
    </div>
    </>
  );
};

export default PatientDetails;
