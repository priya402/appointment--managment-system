import React, { useState, useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../css/DoctorCss/DoctorStatistics.css";
import CustomAlert from '../CustomeAlert'
const DoctorStatistics = () => {
  const doctorId = localStorage.getItem("user_id"); // Assuming the doctor's ID is stored in localStorage

  const [statisticsData, setStatisticsData] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [availabilityData, setAvailabilityData] = useState([]);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info

  useEffect(() => {
    // Fetch appointment statistics (total, completed, etc.)
    const fetchStatistics = async () => {
      try {
        // Fetching appointment data for the doctor
        const appointmentsResponse = await axios.get(
          `http://localhost:8003/appointments/Doctor/${doctorId}`
        );
        
        // Filter completed appointments
        const completedAppointments = appointmentsResponse.data.filter(
          (appointment) => appointment.status === "Completed"
        );

        // Calculate statistics
        const totalAppointments = appointmentsResponse.data.length;
        const completedAppointmentsCount = completedAppointments.length;
        const cancelledAppointmentsCount = totalAppointments - completedAppointmentsCount;

        // Active Patients - Assuming a patientId for unique identification
        const activePatients = new Set(
          appointmentsResponse.data.map((appointment) => appointment.userId)
        ).size;

        // Fetch doctor availability (working hours)
        const availabilityResponse = await axios.get(
          `http://localhost:8002/doctorAvailablity/availability/?doctor_id=${doctorId}`
        );
        
        const availableSlots = availabilityResponse.data;

        // Calculate available hours for each day
        const calculateAvailableHours = (availabilitySlots) => {
          let totalAvailableHours = 0;

          // Iterate over the available slots for the doctor
          availabilitySlots.forEach((slot) => {
            const { day, time_slot, status } = slot;

            // If status is "Available", calculate available time
            if (status === "Available") {
              const startTime = new Date(`1970-01-01T${time_slot}:00`);
              const endTime = new Date(`1970-01-01T${time_slot}:00`);

              // Assuming the time slot duration is 1 hour (can be adjusted)
              endTime.setHours(endTime.getHours() + 1);

              // Calculate the difference in hours
              const availableDuration = (endTime - startTime) / (1000 * 60 * 60);
              totalAvailableHours += availableDuration;
            }
          });

          return totalAvailableHours;
        };

        const totalAvailableHours = calculateAvailableHours(availableSlots);

        setStatisticsData([
          { id: 1, label: "Total Appointments", value: totalAppointments, icon: "calendar-check" },
          { id: 2, label: "Completed Appointments", value: completedAppointmentsCount, icon: "check-circle" },
          { id: 3, label: "Cancelled Appointments", value: cancelledAppointmentsCount, icon: "times-circle" },
          { id: 4, label: "Active Patients", value: activePatients, icon: "user-check" },
          { id: 5, label: "Total Available Hours", value: totalAvailableHours, icon: "clock" },
        ]);

        // Store appointment data for use in completed appointments section
        setAppointments(appointmentsResponse.data);
      } catch (error) {
        setAlertMessage("Error fetching doctor statistics:");
        setAlertVariant("danger");
        setShowAlert(true);
 
      }
    };

    fetchStatistics();
  }, [doctorId]);

  return (
    <>
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        /> 
    <div className="statistics-container mt-4">
      {/* Header */}
      <div className="statistics-header mb-4">
        <h1 className="statistics-title">Doctor Statistics</h1>
        <p className="statistics-subtitle">
          Get insights into your appointment data, patient activities, and availability.
        </p>
      </div>

      {/* Statistics Grid - Displaying the Cards */}
      <div className="row">
        {statisticsData.map((stat) => (
          <div className="col-md-2 col-sm-6 mb-4" key={stat.id}>
            <div className="stat-card shadow-sm">
              <div className="stat-card-body">
                <i className={`bi bi-${stat.icon} stat-icon`} />
                <h3 className="stat-value">{stat.value}</h3>
                <p className="stat-label">{stat.label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Completed Appointments Table */}
      <div className="completed-appointments">
        <h3 className="mb-4 text-center">Completed Appointments</h3>
        <div className="card shadow-sm">
          <div className="card-body">
            <table className="table table-bordered table-hover">
              <thead className="table-light">
                <tr>
                  <th>#</th>
                  <th>Patient Name</th>
                  <th>Appointment Date</th>
                  <th>Appointment Time</th>
                  <th>Symptoms</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {appointments
                  .filter((appointment) => appointment.status === "Completed")
                  .map((appointment) => (
                    <tr key={appointment.id}>
                      <td>{appointment.id}</td>
                      <td>{appointment.userName}</td>
                      <td>{appointment.appointmentDate}</td>
                      <td>{appointment.appointmentTime}</td>
                      <td>{appointment.symptoms}</td>
                      <td>{appointment.status}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default DoctorStatistics;
