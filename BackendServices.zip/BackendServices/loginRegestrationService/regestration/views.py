

from django.shortcuts import render
from django.http import JsonResponse
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from regestration.models import User ,TempUser
import json
import requests
import re
from django.utils.decorators import method_decorator
from mongoengine.errors import ValidationError
from datetime import datetime,timedelta
# Global variable to store OTP for each session

@method_decorator(csrf_exempt, name='dispatch')
class UserRegistrationView(View):

    def post(self, request):
        if request.method != "POST":
            return JsonResponse({"message": "Invalid request method"}, status=405)

        try:
            data = json.loads(request.body)
            action = data.get('action')

            if action == 'register':
                return self.register_and_send_otp(data)
            elif action == 'validate_otp':
                return self.validate_otp(data)
            elif action == 'doctor_register':
                return self.register_doctor(data)
            else:
                return JsonResponse({"message": "Invalid action specified"}, status=400)

        except Exception as e:
            return JsonResponse({"message": str(e)}, status=500)

    def register_and_send_otp(self, data):
        required_fields = ['email', 'name', 'phone_number', 'address', 'role']
        if not all(field in data for field in required_fields):
            return JsonResponse({"message": "Missing required fields"}, status=400)

        if data['role'] == 'admin':
            hospital_key = data.get('hospitalKey')
            if not re.fullmatch(r'[A-Za-z]{3}\d{7}', hospital_key):
                return JsonResponse({"message": "Invalid hospital key for admin role"}, status=400)

        if User.objects(email=data['email']).first():
            return JsonResponse({"message": "Email already registered"}, status=400)
        
        existing_temp_user = TempUser.objects(email=data['email']).first()

        if existing_temp_user:
            # If OTP was sent less than 2 minutes ago, return a message with the wait time
            last_otp_sent_time = existing_temp_user.last_otp_sent_time
            if last_otp_sent_time and (datetime.now() - last_otp_sent_time) < timedelta(minutes=2):
                wait_time = (timedelta(minutes=2) - (datetime.now() - last_otp_sent_time)).seconds
                return JsonResponse({"message": f"OTP already sent. Please wait {wait_time} seconds before requesting another OTP."}, status=400)
            else:
                # If it's been more than 2 minutes, proceed to resend OTP
                existing_temp_user.delete()  # Remove previous entry
                
        otp_service_url = "http://localhost:8000/Mails/RegestrationOtp/"
        otp_response = requests.post(otp_service_url, json={
            "user_email": data['email'],
            "user_name": data['name']
        })

        if otp_response.status_code != 200:
            return JsonResponse({"message": "Failed to send OTP", "details": otp_response.text}, status=otp_response.status_code)

        otp = otp_response.json().get('otp')
        if not otp:
            return JsonResponse({"message": "OTP not returned from service"}, status=500)

        # Save TempUser in MongoDB
        TempUser.objects(email=data['email']).delete()  # remove duplicates
        TempUser(
            email=data['email'],
            name=data['name'],
            phone_number=data['phone_number'],
            address=data['address'],
            role=data['role'],
            hospital_key=data.get('hospitalKey'),
            otp=otp
        ).save()

        return JsonResponse({"message": "OTP sent. Please verify to complete registration."}, status=201)

    def validate_otp(self, data):
        email = data.get('email')
        otp = data.get('otp')

        if not email or not otp:
            return JsonResponse({"message": "Email and OTP are required"}, status=400)

        temp_user = TempUser.objects(email=email).first()
        if not temp_user:
            return JsonResponse({"message": "No OTP request found for this email"}, status=400)

        # Optional: Check OTP expiry
        if datetime.utcnow() - temp_user.created_at > timedelta(minutes=10):
            temp_user.delete()
            return JsonResponse({"message": "OTP expired"}, status=400)

        if temp_user.otp != otp:
            return JsonResponse({"message": "Invalid OTP"}, status=400)

        # OTP is valid → Save user
        user = User(
            email=temp_user.email,
            name=temp_user.name,
            phone_number=temp_user.phone_number,
            address=temp_user.address,
            role=temp_user.role,
            hospital_key=temp_user.hospital_key
        )

        try:
            user.clean()
            user.save()
        except ValidationError as e:
            return JsonResponse({"message": str(e)}, status=400)

        # Delete temp data after registration
        temp_user.delete()

        if user.role == 'user':
            patient_data = {
                "patient_id": str(user.id),
                "name": user.name,
                "email": user.email,
                "phone": user.phone_number,
                "address": user.address
            }
            response = requests.post("http://127.0.0.1:8002/pationt/patients/", json=patient_data)
            if response.status_code != 201:
                return JsonResponse({"message": "Failed to send patient data", "details": response.text}, status=response.status_code)

        return JsonResponse({"message": "OTP verified and user registered successfully"}, status=200)

    def register_doctor(self, data):
        required_fields = ['name', 'email', 'phone_number']
        if not all(field in data for field in required_fields):
            return JsonResponse({"message": "Missing required fields"}, status=400)

        if User.objects(email=data['email']).first():
            return JsonResponse({"message": "Doctor already exists with this email"}, status=400)

        doctor = User(
            name=data['name'],
            email=data['email'],
            phone_number=data['phone_number'],
            role="doctor"
        )

        try:
            doctor.clean()
            doctor.save()
        except ValidationError as e:
            return JsonResponse({"message": str(e)}, status=400)

        return JsonResponse({"message": "Doctor registered successfully", "doctor_id": str(doctor.id)}, status=201)

class UserDeletionView(View):
    @csrf_exempt
    def delete(self, request):
        """
        Deletes a registered user based on email or a request from the doctor service.
        """
        if request.method != "DELETE":
            return JsonResponse({"message": "Invalid request method"}, status=405)

        try:
            data = json.loads(request.body)

            # Ensure email is provided in the request
            if 'email' not in data:
                return JsonResponse({"message": "Email is required for deletion"}, status=400)

            email = data['email']

            # Check if the user exists
            user = User.objects(email=email).first()
            if not user:
                return JsonResponse({"message": "User not found"}, status=404)

            # Handle doctor service deletion
            if data.get('source') == 'doctor_service':
                # Additional validation for doctor service (optional)
                if user.role != 'doctor':
                    return JsonResponse({"message": "This action is not allowed for non-doctor users"}, status=400)

                # Perform additional logic specific to doctor service, if needed
                user.delete()
                return JsonResponse({"message": f"Doctor with email {email} deleted successfully"}, status=200)

            # Handle regular deletion
            user.delete()
            return JsonResponse({"message": f"User with email {email} deleted successfully"}, status=200)

        except Exception as e:
            return JsonResponse({"message": str(e)}, status=500)

