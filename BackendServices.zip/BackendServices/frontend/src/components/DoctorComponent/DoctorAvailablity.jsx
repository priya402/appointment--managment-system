import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../css/DoctorCss/DoctorAvailability.css";
import CustomAlert from '../CustomeAlert'
const DoctorAvailability = () => {
  const [availability, setAvailability] = useState([]);
  const [editMode, setEditMode] = useState(null);
  const [editedTime, setEditedTime] = useState("");
  const [editedStatus, setEditedStatus] = useState("");
  const doctorId = localStorage.getItem("user_id"); // Get doctor_id from localStorage
  // Days of the week for initializing the default data
  const daysOfWeek = [
    "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"
  ];
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
 

  // Fetch availability data from the backend API
  useEffect(() => {
    const fetchAvailability = async () => {
      try {
        const response = await fetch(
          `http://localhost:8002/doctorAvailablity/availability/?doctor_id=${doctorId}`
        );
        if (response.ok) {
          const data = await response.json();
          setAlertMessage("fetched avalablty for you");
          setAlertVariant("success");
          setShowAlert(true);
   
   
   
          // Create a map of availability data from the backend
          const availabilityMap = new Map(
            data.map((item) => [item.day, item])
          );
  
          // Ensure all days are present in the availability list
          const updatedAvailability = daysOfWeek.map((day) => {
            return availabilityMap.has(day)
              ? availabilityMap.get(day) // Use backend data if available
              : { doctor_id: doctorId, day, time_slot: "Not Set", status: "Unavailable" };
          });
  
          setAvailability(updatedAvailability);
        } else {
          setAlertMessage("Faild to fetch data");
          setAlertVariant("danger");
          setShowAlert(true); 
        }
      } catch (error) {
         setAlertMessage("Error at server");
        setAlertVariant("danger");
        setShowAlert(true);
 
 
 
      }
    };
  
    fetchAvailability();
  }, [doctorId]);
  
  // Handle editing availability time for a specific day
  const handleEdit = (doctorId, day, time, status) => {
    setEditMode({ doctorId, day });
    setEditedTime(time);
    setEditedStatus(status);
  };

  // Handle saving the edited time and status, and sending update to the backend
  const handleSave = async (doctorId, day) => {
    const updatedAvailability = availability.map((item) =>
      item.doctor_id === doctorId && item.day === day
        ? { ...item, time_slot: editedTime, status: editedStatus }
        : item
    );
    setAvailability(updatedAvailability);
    setEditMode(null);
  
    // Send update to the backend
    try {
      const response = await fetch(
        "http://localhost:8002/doctorAvailablity/availability/update/",
        {
          method: "PUT",
          body: JSON.stringify({
            doctor_id: localStorage.getItem("user_id"),   // Include doctor_id in the payload
            day: day,
            time_slot: editedTime,
            status: editedStatus,
          }),
          headers: {
            "Content-Type": "application/json"
          }
        }
      );
      if (!response.ok) {
        setAlertMessage("Failed to save availability");
        setAlertVariant("danger");
        setShowAlert(true);
      }
      setAlertMessage("Avalablity Updated");
      setAlertVariant("success");
      setShowAlert(true);



    } catch (error) {
      setAlertMessage("Error updating availability");
      setAlertVariant("danger");
      setShowAlert(true);

    }
  };
  

  // Handle changing the time input value
  const handleTimeChange = (e) => {
    setEditedTime(e.target.value);
  };

  // Handle changing the availability status
  const handleStatusChange = (status) => {
    setEditedStatus(status === "Available" ? "Unavailable" : "Available");
  };

  return (
    <>
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        />
    <div className="doctor-availability-container mt-4">
      {/* Header */}
      <div className="doctor-availability-header mb-4">
        <h1 className="doctor-availability-title">Doctor Availability</h1>
        <p className="doctor-availability-subtitle">
          Manage your available timeslots. Edit your availability for each day.
        </p>
      </div>

      {/* Availability Table */}
      <div className="card shadow-sm c3">
        <div className="card-header bg-primary text-white">
          <h5 className="doctor-availability-subtitle">Availability Schedule</h5>
        </div>
        <div className="card-body">
          <table className="table table-bordered table-hover">
            <thead className="table-light">
              <tr>
                <th>#</th>
                <th>Day</th>
                <th>Time</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {availability.map((item,index) => (
                <tr key={index+1}>
                  <td>{index+1}</td>
                  <td>{item.day}</td>
                  <td>
                    {editMode?.doctorId === item.doctor_id && editMode?.day === item.day ? (
                      <input
                        type="time"
                        value={editedTime}
                        onChange={handleTimeChange}
                        className="form-control"
                      />
                    ) : (
                      item.time_slot
                    )}
                  </td>
                  <td>
                    {editMode?.doctorId === item.doctor_id && editMode?.day === item.day ? (
                      <div>
                        <button
                          className={`btn btn-sm btn-${editedStatus === "Available" ? "success" : "danger"}`}
                          onClick={() => handleStatusChange(item.status)}
                        >
                          {editedStatus}
                        </button>
                      </div>
                    ) : (
                      <span
                        className={`badge ${item.status === "Available" ? "bg-success" : "bg-danger"}`}
                      >
                        {item.status}
                      </span>
                    )}
                  </td>
                  <td className="d-flex">
                    {editMode?.doctorId === item.doctor_id && editMode?.day === item.day ? (
                      <button
                        className="btn btn-sm btn-success"
                        onClick={() => handleSave(item.doctor_id, item.day)}
                      >
                        Save
                      </button>
                    ) : (
                      <button
                        className="btn btn-sm btn-info"
                        onClick={() => handleEdit(item.doctor_id, item.day, item.time_slot, item.status)}
                      >
                        Edit
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
    </>
  );
};

export default DoctorAvailability;
