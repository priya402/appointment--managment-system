from mongoengine import Document, StringField, EmailField, DateTimeField
from datetime import datetime

class Appointment(Document):
    MAIL_TYPES = [
        ("LOGIN_OTP", "Login OTP"),
        ("REGISTRATION_OTP", "Registration OTP"),
        ("APPOINTMENT_CONFIRMATION", "Appointment Confirmation"),
        ("APPOINTMENT_REMINDER", "Appointment Reminder"),
        ("CUSTOM_MESSAGE", "Custom Message"),
    ]

    user_email = EmailField(required=True)
    user_name = StringField(max_length=100, required=True)
    otp = StringField(max_length=6, required=False)
    appointment_date = DateTimeField(required=False)
    created_at = DateTimeField(default=datetime.utcnow)
    mail_type = StringField(choices=MAIL_TYPES, default="CUSTOM_MESSAGE")

    def __str__(self):
        return f"Appointment for {self.user_name} on {self.appointment_date} with type {self.mail_type}"
