from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Appointment
from .serializers import AppointmentSerializer
from django.core.mail import send_mail
from django.conf import settings
import random
from django.views.decorators.csrf import csrf_exempt

def generate_otp():
    return str(random.randint(100000, 999999))

class LoginOTPView(APIView):
    @csrf_exempt
    def post(self, request):
        email = request.data.get('user_email')
        name = request.data.get('user_name')

        if not email or not name:
            return Response({"error": "Email and name are required"}, status=status.HTTP_400_BAD_REQUEST)

        otp = generate_otp()

        # Save OTP in the database
        appointment = Appointment(
            user_email=email,
            user_name=name,
            otp=otp,
            mail_type="LOGIN_OTP"
        )
        appointment.save()

        # Send Email
        send_mail(
            subject="Your Login OTP",
            message=f"Dear {name},\n\nYour login OTP is {otp}. It is valid for 10 minutes.\n\nBest regards,\nYour Company",
            from_email=settings.EMAIL_HOST_USER,
            recipient_list=[email],
            fail_silently=False,
        )

        return Response({"message": "Login OTP sent successfully", "otp": otp}, status=status.HTTP_200_OK)

class RegistrationOTPView(APIView):
    @csrf_exempt
    def post(self, request):
        email = request.data.get('user_email')
        name = request.data.get('user_name')

        if not email or not name:
            return Response({"error": "Email and name are required"}, status=status.HTTP_400_BAD_REQUEST)

        otp = generate_otp()

        # Save OTP in the database
        appointment = Appointment(
            user_email=email,
            user_name=name,
            otp=otp,
            mail_type="REGISTRATION_OTP"
        )
        appointment.save()

        # Send Email
        send_mail(
            subject="Complete Your Registration",
            message=f"Dear {name},\n\nThank you for registering. Your OTP is {otp}. It is valid for 15 minutes.\n\nWarm regards,\nYour Company",
            from_email=settings.EMAIL_HOST_USER,
            recipient_list=[email],
            fail_silently=False,
        )

        return Response({"message": "Registration OTP sent successfully", "otp": otp}, status=status.HTTP_200_OK)

class AppointmentConfirmationView(APIView):
    @csrf_exempt
    def post(self, request):
        email = request.data.get('user_email')
        name = request.data.get('user_name')
        doctor_name=request.data.get('doctor')
        appointment_date = request.data.get('appointment_date')
        appointment_time = request.data.get('appointment_time')


        if not email or not name or not appointment_date:
            return Response({"error": f"Email, name, and appointment date are required {email,name,doctor_name,appointment_time,appointment_date}"}, status=status.HTTP_400_BAD_REQUEST)

        # Save appointment details in the database
        appointment = Appointment(
            user_email=email,
            user_name=name,
            appointment_date=appointment_date,
            mail_type="APPOINTMENT_CONFIRMATION"
        )
        appointment.save()

        # Send Email
        send_mail(
            subject="Appointment Confirmation",
            message=f"Dear {name},\n\nYour appointment is confirmed with {doctor_name} on date {appointment_date} time :{appointment_time}.\n\nThank you for you service,\nif not you contact 8080341618",
            from_email=settings.EMAIL_HOST_USER,
            recipient_list=[email],
            fail_silently=False,
        )

        return Response({"message": "Appointment confirmation email sent successfully"}, status=status.HTTP_200_OK)

class AppointmentReminderView(APIView):
    @csrf_exempt
    def post(self, request):
        email = request.data.get('user_email')
        name = request.data.get('user_name')
        appointment_date = request.data.get('appointment_date')

        if not email or not name or not appointment_date:
            return Response({"error": "Email, name, and appointment date are required"}, status=status.HTTP_400_BAD_REQUEST)

        # Send Email
        send_mail(
            subject="Appointment Reminder",
            message=f"Dear {name},\n\nThis is a reminder for your upcoming appointment on {appointment_date}.\n\nLooking forward to seeing you!\nYour Company",
            from_email=settings.EMAIL_HOST_USER,
            recipient_list=[email],
            fail_silently=False,
        )

        return Response({"message": "Appointment reminder email sent successfully"}, status=status.HTTP_200_OK)

class CustomMessageView(APIView):
    @csrf_exempt
    def post(self, request):
        email = request.data.get('user_email')
        name = request.data.get('user_name')
        message_content = request.data.get('message')

        if not email or not name or not message_content:
            return Response({"error": "Email, name, and message content are required"}, status=status.HTTP_400_BAD_REQUEST)

        # Save message details in the database
        appointment = Appointment(
            user_email=email,
            user_name=name,
            mail_type="CUSTOM_MESSAGE"
        )
        appointment.save()

        # Send Email
        send_mail(
            subject="Custom Message",
            message=f"Dear {name},\n\n{message_content}\n\nBest regards,\nYour Company",
            from_email=settings.EMAIL_HOST_USER,
            recipient_list=[email],
            fail_silently=False,
        )

        return Response({"message": "Custom message sent successfully"}, status=status.HTTP_200_OK)
