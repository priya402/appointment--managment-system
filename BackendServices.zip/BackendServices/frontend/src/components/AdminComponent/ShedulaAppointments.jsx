import React, { useState, useEffect } from "react";
import axios from "axios";
import "../../css/ScheduleAppointment.css";

const ScheduleAppointment = () => {
  const [doctors, setDoctors] = useState([]);
  const [users, setUsers] = useState([]); // State to store all users
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [confirmationMessage, setConfirmationMessage] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]); // State for filtered users
  const [appointmentDetails, setAppointmentDetails] = useState({
    patientName: "",
    doctorId: "",
    appointmentDate: "",
    appointmentTime: "",
    reason: "",
    contact: "",
    communicationMode: "",
    userId: "", // Storing the user ID
  });

  // Fetch available doctors and users from the backend
  useEffect(() => {
    const fetchDoctorsAndUsers = async () => {
      try {
        const [doctorResponse, userResponse] = await Promise.all([
          axios.get("http://localhost:8002/doctor/doctor/"),
          axios.get("http://localhost:8002/pationt/patients/get-all/"), // Replace with your user fetch API endpoint
        ]);
        
        if (doctorResponse.data && doctorResponse.data.length > 0) {
          setDoctors(doctorResponse.data);
        } else {
          setError("No doctors available.");
        }

        if (userResponse.data && userResponse.data.length > 0) {
          setUsers(userResponse.data);
        } else {
          setError("No users available.");
        }
      } catch (err) {
        console.error("Error fetching data:", err);
        setError("Failed to fetch data. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchDoctorsAndUsers();
  }, []);

  const convertTo24HourFormat = (time) => {
    const [hour, minuteWithPeriod] = time.split(":");
    const [minute, period] = minuteWithPeriod.split(" ");
    let hour24 = parseInt(hour);

    if (period === "PM" && hour !== "12") {
      hour24 += 12;
    }

    if (period === "AM" && hour === "12") {
      hour24 = 0;
    }

    return `${hour24.toString().padStart("2", "0")}:${minute}`;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setAppointmentDetails((prev) => ({
      ...prev,
      [name]: value,
    }));

    // Filter users when patientName input changes
    if (name === "patientName") {
      const filtered = users.filter((user) =>
        user.name.toLowerCase().includes(value.toLowerCase())
      );
      setFilteredUsers(filtered);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic form validation
    if (
      !appointmentDetails.patientName ||
      !appointmentDetails.doctorId ||
      !appointmentDetails.appointmentDate ||
      !appointmentDetails.appointmentTime ||
      !appointmentDetails.reason ||
      !appointmentDetails.contact ||
      !appointmentDetails.communicationMode ||
      !appointmentDetails.userId // Ensure userId is selected
    ) {
      setConfirmationMessage("Please fill out all fields.");
      return;
    }

    // Prepare the data to be sent
    const appointmentData = {
      userName: appointmentDetails.patientName, // Patient's name
      userId: appointmentDetails.userId, // Patient's ID
      doctorId: appointmentDetails.doctorId, // Doctor's reg_id
      appointmentDate: appointmentDetails.appointmentDate,
      appointmentTime: appointmentDetails.appointmentTime,
      symptoms: appointmentDetails.reason,
      contact: appointmentDetails.contact,
      communicationMode: appointmentDetails.communicationMode,
    };

    // Send form data to the appointment service
    try {
      const response = await axios.post(
        "http://localhost:8003/appointments/", // Replace with your backend endpoint
        appointmentData
      );
      setConfirmationMessage(response.data.message || "Appointment scheduled successfully!");
    } catch (error) {
      console.error("Error scheduling appointment:", error);
      setConfirmationMessage("An error occurred while scheduling the appointment.");
    }
  };

  return (
    <div className="schedule-appointment-container">
      <header className="header">
        <h2>Schedule Appointment</h2>
      </header>
      <form className="appointment-form" onSubmit={handleSubmit}>
        <div className="form-row">
          <div className="form-group">
            <label htmlFor="patientName">Your Name</label>
            <input
              type="text"
              id="patientName"
              name="patientName"
              value={appointmentDetails.patientName}
              onChange={handleInputChange}
              placeholder="Enter your full name"
            />
            {filteredUsers.length > 0 && (
              <ul className="suggestion-list">
                {filteredUsers.map((user) => (
                  <li
                    key={user.patient_id	}
                    onClick={() => {
                      setAppointmentDetails({
                        ...appointmentDetails,
                        patientName: user.name,
                        userId: user.patient_id	, // Set userId when user is selected
                      });
                      setFilteredUsers([]); // Hide suggestions list
                    }}
                  >
                    {user.name}
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="doctorId">Select Doctor</label>
            {loading ? (
              <p>Loading doctors...</p>
            ) : error ? (
              <p className="error-message">{error}</p>
            ) : (
              <select
                id="doctorId"
                name="doctorId"
                value={appointmentDetails.doctorId}
                onChange={handleInputChange}
              >
                <option value="">Select a doctor</option>
                {doctors.map((doctor) => (
                  <option key={doctor.reg_id} value={doctor.reg_id}>
                    {doctor.name}
                  </option>
                ))}
              </select>
            )}
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="appointmentDate">Select Date</label>
            <input
              type="date"
              id="appointmentDate"
              name="appointmentDate"
              value={appointmentDetails.appointmentDate}
              onChange={handleInputChange}
            />
          </div>

          <div className="form-group">
            <label htmlFor="appointmentTime">Select Time</label>
            <select
              id="appointmentTime"
              name="appointmentTime"
              value={appointmentDetails.appointmentTime}
              onChange={handleInputChange}
            >
              <option value="">Select a time</option>
              {["10:00 AM", "11:30 AM", "1:00 PM", "2:00 PM", "3:30 PM"].map((time, index) => (
                <option key={index} value={convertTo24HourFormat(time)}>
                  {time}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="reason">Reason for Visit</label>
            <textarea
              id="reason"
              name="reason"
              value={appointmentDetails.reason}
              onChange={handleInputChange}
              placeholder="Describe your reason for the visit"
            />
          </div>

          <div className="form-group">
            <label htmlFor="contact">Contact Number</label>
            <input
              type="tel"
              id="contact"
              name="contact"
              value={appointmentDetails.contact}
              onChange={handleInputChange}
              placeholder="Enter your contact number"
            />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="communicationMode">Preferred Communication Mode</label>
            <select
              id="communicationMode"
              name="communicationMode"
              value={appointmentDetails.communicationMode}
              onChange={handleInputChange}
            >
              <option value="">Select communication mode</option>
              {["Phone", "Video Call", "In-Person"].map((mode, index) => (
                <option key={index} value={mode}>
                  {mode}
                </option>
              ))}
            </select>
          </div>
        </div>

        <button type="submit" className="submit-button" disabled={loading || error}>
          Schedule Appointment
        </button>
      </form>

      {confirmationMessage && <div className="confirmation-message">{confirmationMessage}</div>}
    </div>
  );
};

export default ScheduleAppointment;
