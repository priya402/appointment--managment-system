import React, { useState, useEffect } from "react";
import axios from "axios";
import "../../css/DoctorCss/AddPatientNotes.css"; // Custom CSS file for styling
import CustomAlert from '../CustomeAlert'
const AddPatientNotes = () => {
  const [patients, setPatients] = useState([]);
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState("");
  const [selectedPatient, setSelectedPatient] = useState("");
  const [filter, setFilter] = useState("");
  const [showForm, setShowForm] = useState(false); // State to toggle between table and form
  const doctorId = localStorage.getItem("user_id");
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
 
 

  // Fetch patients with completed appointments
  useEffect(() => {
    const fetchPatients = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8003/appointments/Doctor/${doctorId}`
        );
        setPatients(response.data);
        setAlertMessage("Appointment Found");
        setAlertVariant("success");
        setShowAlert(true);
 
 
      } catch (error) {
        setAlertMessage("Error fetching patients");
        setAlertVariant("danger");
        setShowAlert(true);
 
 
      }
    };

    fetchPatients();
  }, [doctorId]);

  // Handle adding a new note
  const handleAddNote = async (e) => {
    e.preventDefault();
    if (selectedPatient && newNote) {
      try {
        // Find the patient object from the 'patients' array using the selectedPatient ID
        const patient = patients.find((patient) => patient.userId === selectedPatient);
  
        // Ensure the patient is found and get their 'userName'
        const patientName = patient ? patient.userName : "Unknown Patient";
  
        const newEntry = {
          patientId: selectedPatient,
          doctorId,
          noteContent: newNote,
          date: new Date().toISOString().split("T")[0],
          patientName: patientName, // Include patientName here
        };
  
        const response = await axios.post(
          "http://localhost:8006/notes/add",
          newEntry
        );
  
        // Add the newly created note to the state
        setNotes([response.data, ...notes]);
        setNewNote("");
        setSelectedPatient("");
        setAlertMessage("Note Creaed For user");
        setAlertVariant("success");
        setShowAlert(true);
 
 
        setShowForm(false); // Hide the form after successful note addition
      } catch (error) {
        setAlertMessage("Error Adding Note");
        setAlertVariant("danger");
        setShowAlert(true);
 
 
      }
    } else {
      setAlertMessage("Please Select patient to add note");
      setAlertVariant("danger");
      setShowAlert(true);
    }
  };

  // Fetch existing notes for the doctor
  useEffect(() => {
    const fetchNotes = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8006/notes/doctor/${doctorId}`
        );
        setNotes(response.data);
        setAlertMessage("Note Found for you");
        setAlertVariant("success");
        setShowAlert(true);
 
 
      } catch (error) {
        setAlertMessage("Error Fetching note");
        setAlertVariant("danger");
        setShowAlert(true);
 
 
      }
    };

    fetchNotes();
  }, [doctorId]);

  // Filter notes based on the selected filter
  const filteredNotes = filter
    ? notes.filter((note) => note.patientId === filter)
    : notes;

  return (
    <>
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        />
    <div className="patient-notes-container">
      {/* Header */}
      <div className="patient-notes-header">
        <h1 className="patient-notes-title">Patient Notes</h1>
        <p className="patient-notes-description">
          View, add, and manage notes for your patients.
        </p>
      </div>

      {/* Toggle button for showing form */}
      {!showForm && (
        <button
          className="patient-notes-btn"
          onClick={() => setShowForm(true)}
        >
          Add New Note
        </button>
      )}

      {/* Add Note Form */}
      {showForm && (
        <div className="patient-notes-card">
          <div className="patient-notes-card-header">
            <h5>Add New Note</h5>
          </div>
          <div className="patient-notes-card-body">
            <form onSubmit={handleAddNote}>
              <div className="form-group">
                <label htmlFor="patient" className="form-label">
                  Select Patient
                </label>
                <select
                  className="form-select"
                  id="patient"
                  value={selectedPatient}
                  onChange={(e) => setSelectedPatient(e.target.value)}
                >
                  <option value="">-- Select Patient --</option>
                  {patients.map((patient) => (
                    <option key={patient.userId} value={patient.userId}>
                      {patient.userName}
                    </option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label htmlFor="note" className="form-label">
                  Note
                </label>
                <textarea
                  className="form-control"
                  id="note"
                  rows="4"
                  placeholder="Enter your note here..."
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                ></textarea>
              </div>
              <div className="d-flex gap-5 justify-content-center">
              <button type="submit" className="patient-notes-btn">
                Add Note
              </button>
              <button type="submit" className="patient-notes-btn" onClick={()=>setShowForm(false)}>
                cancle
              </button>
              </div>
              
            </form>
          </div>
        </div>
      )}

      {/* Filter Notes Section */}
      {!showForm && (
        <div className="patient-notes-filter">
          <label htmlFor="filter" className="form-label">
            Filter by Patient
          </label>
          <select
            className="form-select"
            id="filter"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="">-- Show All --</option>
            {patients.map((patient) => (
              <option key={patient.userId} value={patient.userId}>
                {patient.userName}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Notes List */}
      {!showForm && (
        <div className="patient-notes-list">
          <div className="patient-notes-card-header">
            <h5>Patient Notes</h5>
          </div>
          <div className="patient-notes-card-body">
            {filteredNotes.length > 0 ? (
              <ul className="patient-notes-list-group">
                {filteredNotes.map((note) => (
                  <li key={note.id} className="patient-notes-list-item">
                    <strong>{note.patientName}</strong> <br />
                    <small className="text-muted">{note.date}</small>
                    <p className="patient-notes-text">{note.noteContent}</p>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted">No notes found for the selected filter.</p>
            )}
          </div>
        </div>
      )}
    </div>
    </>
  );
};

export default AddPatientNotes;
