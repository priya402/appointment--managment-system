import React, { useEffect, useState } from "react";
import axios from "axios";
import '../../css/UserCss/NotesPage.css'
import CustomAlert from '../CustomeAlert'
const NotesPage = () => {
    const [notes, setNotes] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
   

    useEffect(() => {
        const fetchNotes = async () => {
            const userId = localStorage.getItem("user_id");
            if (!userId) {
                setError("User ID not found in localStorage.");
                setLoading(false);
                return;
            }

            try {
                // Fetch notes from backend
                const response = await axios.get(`http://localhost:8006/notes/patient/${userId}`);

                let notesData = response.data || [];

                // Fetch doctor names for each note
                const doctorPromises = notesData.map(async (note) => {
                    try {
                        const doctorResponse = await axios.get(`http://localhost:8002/doctor/doctor/id/${note.doctorId}/`);
                        return { ...note, doctorName: doctorResponse.data.name || "Unknown Doctor" };
                    } catch (err) {
                        return { ...note, doctorName: "Unknown Doctor" };
                    }
                });

                const updatedNotes = await Promise.all(doctorPromises);
                
                // Sort notes by date (newest first)
                const sortedNotes = updatedNotes.sort((a, b) => new Date(b.date) - new Date(a.date));
                setNotes(sortedNotes);
                setAlertMessage("Notes get for you");
                setAlertVariant("success");
                setShowAlert(true);
         
         
            } catch (error) {
                setError("Failed to fetch notes. Please try again.");
                setAlertMessage("Faild to load please try again");
                setAlertVariant("danger");
                setShowAlert(true);
         
         
            } finally {
                setLoading(false);
            }
        };

        fetchNotes();
    }, []);

    return (
        <>
          <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        />
        <div className="notes-container">
            <h2>User Notes</h2>
            {loading && <p className="loading">Loading...</p>}
            {!loading && !error && notes.length === 0 && <p className="no-notes">No notes available.</p>}
                {notes.map((note) => (
                    <div key={note.patientId + note.date} className="note-card">
                        <div className="note-header">
                            <span className="note-date">{new Date(note.date).toLocaleDateString()}</span>
                            <span className="note-time">{new Date(note.date).toLocaleTimeString()}</span>
                        </div>
                        <p className="note-content"><strong>Note:</strong> {note.noteContent}</p>
                        <p className="note-info"><strong>Patient:</strong> {note.patientName}</p>
                        <p className="note-info"><strong>Doctor:</strong> {note.doctorName}</p>
                    </div>
                ))}
        </div>
        </>
    );
};

export default NotesPage;
