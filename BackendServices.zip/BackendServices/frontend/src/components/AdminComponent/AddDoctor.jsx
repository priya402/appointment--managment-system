import React, { useState } from "react";
import "../../css/AddDoctor.css";
import CustomAlert from '../CustomeAlert'
const AddDoctor = () => {
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info

  const initialDoctorState = {
    name: "",
    specialization: "",
    contact: "",
    email: "",
    address: "",
    qualifications: "",
    experience: "",
    doctor_number: "",
    emergency_contact: "",
    aadhar_number: "",
    image: null,
    aadhar_image: null,
    hos_id: localStorage.getItem("hospital_key"),
  };
  
  const [newDoctor, setNewDoctor] = useState(initialDoctorState);


  

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewDoctor((prev) => ({ ...prev, [name]: value }));
  };

  // Convert image to Base64 and update state
  const handleImageChange = (e, type) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewDoctor((prev) => ({ ...prev, [type]: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate required fields before submitting
    for (let key in newDoctor) {
      if (!newDoctor[key]) {
        alert(`${key.replace("_", " ")} is required.`);
        return;
      }
    }

    try {
      const response = await fetch("http://localhost:8002/doctor/doctor/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newDoctor),
      });

      const result = await response.json();
      
      setAlertMessage("Doctor Added Success");
      setAlertVariant("success");
      setNewDoctor(initialDoctorState);
      setShowAlert(true);

    } catch (error) {
      setAlertMessage("Cant add doctor ");
      setAlertVariant("danger");
      setShowAlert(true);

    }
  };

  return (
    <>
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        /> 
    <div className="add-doctor-container">
      <header className="header">
        <h2>Add New Doctor</h2>
      </header>
      <div className="add-doctor-card">
        <div className="add-doctor-header">
          <div
            className="doctor-image-container"
            onClick={() => document.getElementById("fileInput").click()}
            style={{
              backgroundImage: newDoctor.image ? `url(${newDoctor.image})` : "none",
              backgroundColor: newDoctor.image ? "transparent" : "#f0f0f0",
            }}
          >
            {!newDoctor.image && <span className="image-placeholder-text">+ Add Image</span>}
          </div>
          <input
            type="file"
            accept="image/*"
            id="fileInput"
            onChange={(e) => handleImageChange(e, "image")}
            style={{ display: "none" }}
          />
        </div>
        <form onSubmit={handleSubmit} className="doctor-form">
          <div className="doctor-info">
            {[
              { label: "Name", name: "name" },
              { label: "Specialization", name: "specialization" },
              { label: "Contact", name: "contact" },
              { label: "Email", name: "email" },
              { label: "Address", name: "address" },
              { label: "Qualifications", name: "qualifications" },
              { label: "Experience", name: "experience" },
              { label: "Doctor Number", name: "doctor_number" }, // Fixed field name
              { label: "Emergency Contact", name: "emergency_contact" }, // Fixed field name
              { label: "Aadhar Number", name: "aadhar_number" }, // Fixed field name
            ].map(({ label, name }) => (
              <div key={name} className="doctor-info-item">
                <label>{label}:</label>
                <input
                  type="text"
                  name={name}
                  value={newDoctor[name]}
                  onChange={handleInputChange}
                  className="editable-input"
                  required
                />
              </div>
            ))}

            {/* Aadhar Image Field */}
            <div className="doctor-info-item">
              <label>Aadhar Image:</label>
              <div
                className="aadhar-image-container"
                onClick={() => document.getElementById("aadharFileInput").click()}
              >
                {!newDoctor.aadhar_image && <span className="aadhar-image-placeholder-text">+ Aadhar Image</span>}
              </div>
              <input
                type="file"
                accept="image/*"
                id="aadharFileInput"
                onChange={(e) => handleImageChange(e, "aadhar_image")}
                style={{ display: "none" }}
              />
            </div>
          </div>

          <div className="action-buttons">
            <button className="btn submit-button" type="submit">
              Submit
            </button>
            <button className="btn cancel-button" type="button">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
    </>
  );
};

export default AddDoctor;
