from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from regestration.models import User
import json
import requests
from django.views import View
from regestration.models import User

# Global dictionary to store OTPs temporarily (for demonstration purposes)
# Ideally, use a session, database, or cache for this in production
otp_storage = {}

OTP_SERVICE_URL = "http://localhost:8000/Mails/LoginOtp/"

class OTPService:
    @staticmethod
    def send_otp(user, email):
        """
        Sends OTP to the user and stores it temporarily for validation.
        """
        # Send the user's name and email to the OTP service
        otp_response = requests.post(OTP_SERVICE_URL, json={"user_email": email, "user_name": user.name})
        
        if otp_response.status_code != 200:
            return JsonResponse({"message": "Failed to send OTP"}, status=otp_response.status_code)

        otp = otp_response.json().get('otp')  # Assuming OTP service sends back the OTP

        # Store OTP in the global dictionary temporarily (for demo purposes)
        otp_storage[email] = otp

        return JsonResponse({"message": "OTP sent. Please verify OTP."}, status=200)

    @staticmethod
    def validate_otp(email, user_otp):
        """
        Validates the OTP entered by the user and includes the role in the response.
        """
        # Check if the OTP exists in the storage and matches
        if email not in otp_storage:
            return JsonResponse({"message": "OTP not sent or expired"}, status=400)

        # Compare the stored OTP with the user input OTP
        stored_otp = otp_storage[email]
        if stored_otp == user_otp:
            # Fetch user details from the database
            user = User.objects(email=email).first()
            if not user:
                return JsonResponse({"message": "User not found"}, status=404)

            user_id = None
            hospitalKey = None  # Initialize hospitalKey to prevent errors

            if user.role == 'user':
                try:
                    response = requests.get(f"http://localhost:8002/pationt/patientsDetails/email/{email}")
                    response.raise_for_status()  
                    user_id = response.json().get("patient_id")  
                except requests.exceptions.RequestException as e:
                    return JsonResponse({"message": f"Error fetching patient details: {str(e)}"}, status=500)

            elif user.role == 'doctor':
                try:
                    response = requests.get(f"http://localhost:8002/doctor/doctor/email/{email}")
                    response.raise_for_status()  
                    user_id = response.json().get("reg_id")  
                except requests.exceptions.RequestException as e:
                    return JsonResponse({"message": f"Error fetching doctor details: {str(e)}"}, status=500)

            elif user.role == 'admin':
                user_id = str(user.id)  
                hospitalKey = str(user.hospital_key)  # Assign value for admin

            # OTP is valid, authentication successful
            return JsonResponse({
                "message": "OTP validated successfully. User authenticated.",
                "auth_status": True,
                "role": user.role,  
                "user_id": user_id,
                "hospital_key": hospitalKey  # Will be None for users & doctors
            }, status=200)

        else:
            return JsonResponse({"message": "Invalid OTP"}, status=400)

class LoginView(View):
    @csrf_exempt
    def post(self, request):
        """
        Handles the OTP sending and validation for user login.
        """
        if request.method != "POST":
            return JsonResponse({"message": "Invalid request method"}, status=405)

        try:
            data = json.loads(request.body)

            # Check if email is provided
            if 'email' not in data:
                return JsonResponse({"message": "Email is required"}, status=400)

            # Fetch user by email
            user = User.objects(email=data['email']).first()
            if not user:
                return JsonResponse({"message": "User not found"}, status=404)

            # Check if action is 'send_otp' or 'validate_otp'
            if 'action' not in data:
                return JsonResponse({"message": "Action is required"}, status=400)

            action = data['action']

            if action == 'send_otp':
                return OTPService.send_otp(user, data['email'])
            elif action == 'validate_otp':
                return OTPService.validate_otp(data['email'], data['otp'])
            else:
                return JsonResponse({"message": "Invalid action specified"}, status=400)

        except Exception as e:
            return JsonResponse({"message": str(e)}, status=500)
