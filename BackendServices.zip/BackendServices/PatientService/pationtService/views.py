from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Patient
from .serializers import PatientSerializer


class PatientCreateView(APIView):
    
    def post(self, request):
            patient_data = request.data
            # Ensure that the patient_id field is present in the request
            if 'patient_id' not in patient_data:
                return Response({"message": "Patient ID is required"}, status=status.HTTP_400_BAD_REQUEST)

            # Create and save the patient record
            serializer = PatientSerializer(data=patient_data)
            if serializer.is_valid():
                serializer.save()
                return Response({"message": "Patient record created successfully", "data": serializer.data}, status=status.HTTP_201_CREATED)

            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
class PatientListView(APIView):
    """
    Retrieve all patients.
    """
    def get(self, request):
        patients = Patient.objects.all()
        serializer = PatientSerializer(patients, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)



class PatientDetailView(APIView):
    """
    Retrieve, update, or delete a patient record.
    """
    def get(self, request, patient_id=None, email=None):
        try:
            if patient_id:
                patient = Patient.objects.filter(patient_id=patient_id).first()
            elif email:
                patient = Patient.objects.filter(email=email).first()
            else:
                return Response({"message": "Invalid parameters"}, status=status.HTTP_400_BAD_REQUEST)
        except Patient.DoesNotExist:
            return Response({"message": "Patient not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer = PatientSerializer(patient)
        return Response(serializer.data)


    def put(self, request, patient_id):
        try:
            patient = Patient.objects.get(patient_id=patient_id)
        except Patient.DoesNotExist:
            return Response({"message": "Patient not found"}, status=status.HTTP_404_NOT_FOUND)

        serializer = PatientSerializer(patient, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Patient updated successfully", "data": serializer.data})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, patient_id):
        try:
            patient = Patient.objects.get(patient_id=patient_id)
            patient.delete()
            return Response({"message": "Patient deleted successfully"}, status=status.HTTP_204_NO_CONTENT)
        except Patient.DoesNotExist:
            return Response({"message": "Patient not found"}, status=status.HTTP_404_NOT_FOUND)
