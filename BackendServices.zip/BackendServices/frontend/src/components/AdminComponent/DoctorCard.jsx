import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BsFillPhoneFill, BsFillEnvelopeFill, BsFillCalendarFill, BsFillBriefcaseFill } from 'react-icons/bs';
import axios from 'axios';
import '../../css/DoctorCard.css';
import CustomAlert from '../CustomeAlert';

const DoctorCard = () => {
    const [doctors, setDoctors] = useState([]);
    const [availability, setAvailability] = useState({});
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
  
    const navigate = useNavigate();
    const hospitalKey = localStorage.getItem('hospital_key'); // Retrieve hospital_key from localStorage

    useEffect(() => {
        const fetchDoctors = async () => {
            try {
                const response = await axios.get('http://localhost:8002/doctor/doctor/');
                const filteredDoctors = response.data.filter(doctor => doctor.hos_id === hospitalKey);
                setDoctors(filteredDoctors);
                setAlertMessage(response.data.length>0 ?"Doctor Found ":"no doctor avalable please add");
                setAlertVariant("success");
                setShowAlert(true);
            } catch (error) {
                console.error('Error fetching doctors:', error);
                setAlertMessage("Error fetching doctors");
                setAlertVariant("danger");
                setShowAlert(true);
            }
        };
        fetchDoctors();
    }, [hospitalKey]);

    const fetchAvailability = async (doctorId) => {  
        try {
            const response = await axios.get(`http://localhost:8002/doctorAvailablity/availability/?doctor_id=${doctorId}`);
            setAlertMessage("Data Found");
            setAlertVariant("success");
            setShowAlert(true);
            return response.data;
        } catch (error) {
            setAlertMessage("Error fetching availability for doctor");
            setAlertVariant("danger");
            setShowAlert(true);
            return [];
        }
    };

    const getTodayAvailability = (availabilityData) => {
        const today = new Date().toLocaleString('en-US', { weekday: 'long' });
        const todaySlots = availabilityData
            .filter(slot => slot.day === today && slot.status === "Available")
            .map(slot => slot.time_slot)
            .join(", ");
        return todaySlots.length > 0 ? todaySlots : "Not Available";
    };

    useEffect(() => {
        const fetchAllAvailability = async () => {
            const availabilityMap = {};
            for (const doctor of doctors) {
                const availData = await fetchAvailability(doctor.reg_id);
                availabilityMap[doctor.reg_id] = getTodayAvailability(availData);
            }
            setAvailability(availabilityMap);
        };

        if (doctors.length > 0) {
            fetchAllAvailability();
        }
    }, [doctors]);

    return (
        <>
        <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        /> 
        <main className="doctors-container">
            <div className="row">
                <div className="col-12">
                    <h3 className="doctors-title">View All Doctors</h3>
                </div>
            </div>

            <div className="row mt-4">
                {doctors.length === 0 ? (
                    <div className="col-12 text-center">
                        <p>No doctors available at the moment.</p>
                    </div>
                ) : (
                    doctors.map((doctor) => (
                        <div key={doctor.id} className="col-md-3 col-sm-6 mb-4">
                            <div className="card doctor-card">
                                <div className="card-body">
                                    <div className="doctor-header">
                                        <div className="doctor-image">
                                            <img
                                                src={doctor.image}
                                                alt={doctor.name}
                                                className="img-fluid"
                                            />
                                        </div>
                                        <div className="row">
                                            <div className="doctor-info d-flex col-12 text-center">
                                                <h5>{doctor.name}</h5>
                                            </div>
                                            <div className="doctor-designation col-12 text-center ">
                                                <p><BsFillBriefcaseFill /> {doctor.specialization}</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="doctor-summary">
                                        <p><BsFillPhoneFill /> {doctor.contact}</p>
                                        <p><BsFillEnvelopeFill /> {doctor.email}</p>
                                        <p><BsFillCalendarFill /> <strong>Today’s Availability:</strong> {availability[doctor.reg_id] || "Loading..."}</p>
                                    </div>

                                    <div className="doctor-actions">
                                        <button className="btn btn-view" onClick={() => navigate(`/doctor/${doctor.reg_id}`)}>
                                            View Doctor
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </main>
        </>
    );
};

export default DoctorCard;
