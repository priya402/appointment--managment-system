from django.urls import path
from .views import get_availability, update_or_create_availability

urlpatterns = [
    path('availability/', get_availability, name='get_availability'),
    path('availability/update/', update_or_create_availability, name='update_availability'),
]
