import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom"; // For navigation
import "../../css/UserCss/Dashboard.css";
import CustomAlert from "../CustomeAlert";

const UserDashboard = () => {
    const [userDetails, setUserDetails] = useState({});
    const [upcomingAppointments, setUpcomingAppointments] = useState([]);
    const [pastAppointments, setPastAppointments] = useState([]);
    
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
    const [loading, setLoading] = useState(false);

    const navigate = useNavigate(); // Hook for navigation

    // Fetch user details from the backend
    useEffect(() => {
        const userId = localStorage.getItem("user_id"); // Get user ID from local storage
        if (!userId) {
            setAlertMessage("User ID not found in local storage.");
            setAlertVariant("danger");
            setShowAlert(true);
            setLoading(false);
            return;
        }

        const fetchUserDetails = async () => {
            try {
                const response = await fetch(`http://localhost:8002/pationt/patientsDetails/id/${userId}/`, {
                    method: "GET",
                    headers: { "Content-Type": "application/json" },
                });

                if (!response.ok) {
                    setAlertMessage("No Data Found for user");
                    setAlertVariant("danger");
                    setShowAlert(true);
                    return;
                }

                const data = await response.json();
                setUserDetails(data);
                setAlertMessage("User found");
                setAlertVariant("success");
                setShowAlert(true);
            } catch (err) {
                setAlertMessage("Server error: " + err);
                setAlertVariant("danger");
                setShowAlert(true);
            }
        };

        fetchUserDetails();
    }, []);

    // Fetch appointment details
    useEffect(() => {
        const userId = localStorage.getItem("user_id");
        if (!userId) return;

        const fetchAppointments = async () => {
            try {
                const response = await fetch(`http://3.6.33.150:8003/appointments/User/${userId}`, {
                    method: "GET",
                    headers: { "Content-Type": "application/json" },
                });

                if (!response.ok) {
                    setAlertMessage("No appointment data found");
                    setAlertVariant("warning");
                    setShowAlert(true);
                    return;
                }

                const data = await response.json();
                const today = new Date();

                // Categorize appointments into past and upcoming
                const upcoming = [];
                const past = [];

                data.forEach((appt) => {
                    const appointmentDate = new Date(appt.date);
                    if (appointmentDate >= today) {
                        past.push(appt);

                    } else {
                        upcoming.push(appt);

                    }
                });

                setUpcomingAppointments(upcoming);
                setPastAppointments(past);
            } catch (err) {
                setAlertMessage("Error fetching appointments: " + err);
                setAlertVariant("danger");
                setShowAlert(true);
            }
        };

        fetchAppointments();
    }, []);

    const calculateAge = (dob) => {
        const birthDate = new Date(dob);
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        if (today.getMonth() < birthDate.getMonth() || 
            (today.getMonth() === birthDate.getMonth() && today.getDate() < birthDate.getDate())) {
            age--;
        }
        return age;
    };

    // Navigate to the appointment view page
    const handleViewMore = () => {
        navigate("/ViewAppointment");
    };

    return (
        <>
            <CustomAlert
                show={showAlert}
                message={alertMessage}
                variant={alertVariant}
                onClose={() => setShowAlert(false)}
            />
            <div className="user-dashboard">
                <header className="dashboard-header">
                    <h2>Welcome, {userDetails.name}</h2>
                </header>

                <section className="dashboard-content">
                    {/* User Information */}
                    <div className="user-info c1">
                        <h3>Personal Information</h3>
                        <div className="info-item"><strong>Name:</strong> {userDetails.name}</div>
                        <div className="info-item"><strong>Email:</strong> {userDetails.email}</div>
                        <div className="info-item"><strong>Phone:</strong> {userDetails.phone}</div>
                        <div className="info-item"><strong>Age:</strong> {calculateAge(userDetails.dob)}</div>
                        <div className="info-item"><strong>Gender:</strong> {userDetails.gender}</div>
                    </div>

                    {/* Upcoming and Past Appointments */}
                    <div className="row-layout">
                        {/* Upcoming Appointments */}
                        <div className="appointments c1">
                            <h3>Upcoming Appointments</h3>
                            {upcomingAppointments.length > 0 ? (
                                upcomingAppointments.slice(0,2).map((appt) => (
                                    <div key={appt.id} className="appointment-item">
                                        <div><strong>Doctor:</strong> {appt.doctor}</div>
                                        <div><strong>Date:</strong> {appt.appointmentDate}</div>
                                        <div><strong>Time:</strong> {appt.appointmentTime}</div>
                                        <div className={`status ${appt.status ? appt.status.toLowerCase() : "unknown"}`}>
    Status: {appt.status ?? "Unknown"}
</div>                                    </div>
                                ))
                            ) : (
                                <p>No upcoming appointments</p>
                            )}
                            <button className="view-more" onClick={handleViewMore}>View More</button>
                        </div>

                        {/* Past Appointments */}
                        <div className="appointments c1">
                            <h3>Past Appointments</h3>
                            {pastAppointments.length > 0 ? (
                                pastAppointments.slice(0,2).map((appt) => (
                                    <div key={appt.id} className="appointment-item">
                                        <div><strong>Doctor:</strong> {appt.doctor}</div>
                                        <div><strong>Date:</strong> {appt.appointmentDate}</div>
                                        <div><strong>Time:</strong> {appt.appointmentTime	}</div>
                                        <div className={`status ${appt.status ? appt.status.toLowerCase() : "unknown"}`}>
    Status: {appt.status ?? "Unknown"}
</div>
                                    </div>
                                ))
                            ) : (
                                <p>No past appointments</p>
                            )}
                            <button className="view-more" onClick={handleViewMore}>View More</button>
                        </div>
                    </div>
                </section>
            </div>
        </>
    );
};

export default UserDashboard;
