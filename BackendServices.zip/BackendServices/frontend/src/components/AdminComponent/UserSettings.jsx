import React, { useState } from "react";
import "../../css/Setting.css";

const UserSettings = () => {
  const [userDetails, setUserDetails] = useState({
    username: "",
    email: "",
    phone: "",
    notifications: false,
    profileVisibility: "public",
    themePreference: "light",
  });

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setUserDetails((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSaveSettings = () => {
    console.log("User settings saved!", userDetails);
  };

  return (
    <div className="settings-container">
      <header className="header">
        <h2>User Settings</h2>
      </header>
      <div className="settings-form">
        {/* Personal Information */}
        <h3 className="section-title">Personal Information</h3>
        <div className="form-group">
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            name="username"
            value={userDetails.username}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={userDetails.email}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="phone">Phone:</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={userDetails.phone}
            onChange={handleInputChange}
          />
        </div>

        {/* Preferences */}
        <h3 className="section-title">Preferences</h3>
        <div className="form-group">
          <label htmlFor="notifications">Enable Notifications:</label>
          <input
            type="checkbox"
            id="notifications"
            name="notifications"
            checked={userDetails.notifications}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="profileVisibility">Profile Visibility:</label>
          <select
            id="profileVisibility"
            name="profileVisibility"
            value={userDetails.profileVisibility}
            onChange={handleInputChange}
          >
            <option value="public">Public</option>
            <option value="private">Private</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="themePreference">Theme Preference:</label>
          <select
            id="themePreference"
            name="themePreference"
            value={userDetails.themePreference}
            onChange={handleInputChange}
          >
            <option value="light">Light</option>
            <option value="dark">Dark</option>
          </select>
        </div>

        <div className="action-buttons">
          <button className="btn btn-save" onClick={handleSaveSettings}>
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
};

export default UserSettings;
