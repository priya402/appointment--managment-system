import React, { useState } from 'react';
import '../css/AboutUs.css';

import devloper1 from '../assets/developer1.jpeg';
import devloper2 from '../assets/developer2.jpeg';

const AboutPage = () => {
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [message, setMessage] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [contactDeveloper, setContactDeveloper] = useState(null);
  const [developerEmail, setDeveloperEmail] = useState('');
  const [responseMessage, setResponseMessage] = useState('');

  // Handle form submission for sending email
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Formatting the message
    const formattedMessage = `Hey, my name is ${userName}. My contact is ${userEmail}. Here is my message: ${message}`;

    const formData = {
      user_name: contactDeveloper,  // Sending developer's name as the user_name
      user_email: developerEmail,   // Developer's email
      message: formattedMessage,    // The formatted message
    };

    fetch('http://localhost:8000/Mails/CustomMessage/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    })
    .then(response => response.json())
    .then(data => {
      if (data.message=="Custom message sent successfully") {
        setResponseMessage('Custom message sent successfully');
      } else {
        setResponseMessage('Failed to send message.');
      }
      setModalOpen(false);
    })
    .catch(err => {
      setResponseMessage('Error sending message');
      setModalOpen(false);
    });
  };

  return (
    <div className="about-page">
      {responseMessage && (
        <div className="response-message">
          <p>{responseMessage}</p>
        </div>
      )}
      <h2>About AMS</h2>

      {/* Developer Cards */}
      <div className="developers">
        <div className="developer-card">
          <img src={devloper1} alt="Developer 1" />
          <h3>Developer 1</h3>
          <p>Role: Backend Developer</p>
          <p>Experience: 1 years in React , Django, Spring Boot, and Microservices</p>
          <button onClick={() => { 
            setContactDeveloper('Yash Gorde');
            setDeveloperEmail('gordeyash798@gmail.com');
            setModalOpen(true); 
          }}>
            Contact Yash
          </button>
        </div>

        <div className="developer-card">
          <img src={devloper2} alt="Developer 2" />
          <h3>Developer 2</h3>
          <p>Role: Frontend Developer</p>
          <p>Experience: 6 months in React, spring boot</p>
          <button onClick={() => { 
            setContactDeveloper('Priya Gunjal');
            setDeveloperEmail('priyagunjal2004@gmail.com');
            setModalOpen(true); 
          }}>
            Contact Priya
          </button>
        </div>
      </div>

      {/* Appointment Management Project Details */}
      <section className="project-details">
  <h3>About the Appointment Management System</h3>
  <p>
    The Appointment Management System (AMS) is a robust, scalable solution designed to optimize the appointment scheduling process for healthcare professionals and patients. Built using a microservices architecture, AMS ensures seamless communication and high availability, allowing for easy scheduling, rescheduling, and management of appointments. The system also provides real-time notifications to both patients and doctors, enhancing their experience by keeping them informed of changes or updates. 
  </p>
  <p>
    The system is equipped with role-based features, enabling three distinct user roles: Admin, Doctor, and Patient. Admins can manage user access, appointments, and oversee system performance. Doctors can manage their schedules and patient interactions, while patients can easily book, view, and modify their appointments.
  </p>
  <p>
    In addition to its core functionalities, AMS includes an OTP validation system for secure user authentication and integrates a mail-sending service to notify users of appointment details, confirmations, and reminders.
  </p>

  <h3>Key Features</h3>
  <ol>
    <li><strong>Microservices Architecture:</strong> The system is built with a scalable microservices architecture, ensuring high availability and fault tolerance as the application grows.</li>
    <li><strong>Role-Based Access Control:</strong> Admins, doctors, and patients have unique permissions and features tailored to their specific needs, enhancing user experience and security.</li>
    <li><strong>OTP Validation:</strong> Secure authentication and user verification are ensured through OTP validation, protecting against unauthorized access.</li>
    <li><strong>Mail Notification Service:</strong> Automatic email notifications are sent to users for appointment confirmations, reminders, and important updates.</li>
    <li><strong>Real-Time Updates:</strong> Both patients and doctors receive real-time notifications for appointments, cancellations, and other updates, improving coordination and reducing wait times.</li>
    <li><strong>Scalable and Maintainable:</strong> The microservices-based architecture makes the system easily scalable and maintainable, allowing for smooth upgrades and the addition of new features without disrupting the existing system.</li>
  </ol>
  
  <h3>Project Benefits</h3>
  <ul>
    <li>Efficient appointment scheduling, rescheduling, and management.</li>
    <li>Enhanced security and user experience through OTP-based validation.</li>
    <li>Real-time notifications and updates for improved communication.</li>
    <li>Improved patient care with reduced waiting times and better coordination.</li>
    <li>Seamless integration with existing patient management systems for a streamlined workflow.</li>
  </ul>
</section>

      {/* Modal for Contact Form */}
      {modalOpen && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h2>Contact {contactDeveloper}</h2>
            <form onSubmit={handleSubmit}>
              <input
                type="text"
                placeholder="Your Name"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                required
              />
              <input
                type="email"
                placeholder="Your Email"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                required
              />
              <textarea
                placeholder="Your Message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
              />
              <button type="submit">Send Message</button>
              <button type="button" onClick={() => setModalOpen(false)}>Close</button>
            </form>
          </div>
        </div>
      )}

      {/* Display response message */}
      
    </div>
  );
};

export default AboutPage;
