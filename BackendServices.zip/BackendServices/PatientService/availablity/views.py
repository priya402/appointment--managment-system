from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import DoctorAvailability
from .serializser import DoctorAvailabilitySerializer
from DoctorService.models import DoctorDetails  # Import the DoctorDetails model

# GET doctor's availability
@api_view(['GET'])
def get_availability(request):
    doctor_id = request.query_params.get('doctor_id')  # Get doctor_id from query params
    if not doctor_id:
        return Response({"error": "doctor_id is required"}, status=status.HTTP_400_BAD_REQUEST)

    # Fetch doctor using reg_id (doctor_id)
    doctor = get_object_or_404(DoctorDetails, reg_id=doctor_id)  # Get doctor by reg_id
    availabilities = DoctorAvailability.objects.filter(doctor=doctor)
    serializer = DoctorAvailabilitySerializer(availabilities, many=True)
    return Response(serializer.data)

# UPDATE or CREATE availability
@api_view(['PUT', 'POST'])
def update_or_create_availability(request):
    doctor_id = request.data.get('doctor_id')  # Get doctor_id from request body
    if not doctor_id:
        return Response({"error": "doctor_id is required"}, status=status.HTTP_400_BAD_REQUEST)

    # Fetch the doctor using the reg_id (assuming 'doctor_id' corresponds to 'reg_id' in the DoctorDetails model)
    try:
        doctor = DoctorDetails.objects.get(reg_id=doctor_id)  # Fetch doctor by reg_id
    except DoctorDetails.DoesNotExist:
        return Response({"error": "Doctor not found"}, status=status.HTTP_404_NOT_FOUND)

    day = request.data.get('day')
    if not day:
        return Response({"error": "day is required"}, status=status.HTTP_400_BAD_REQUEST)

    # Check if the availability record exists for the doctor on the given day
    availability, created = DoctorAvailability.objects.get_or_create(doctor=doctor, day=day)

    # If it's an existing record, update it; otherwise, create a new record
    if not created:
        # Update the existing record
        serializer = DoctorAvailabilitySerializer(availability, data=request.data, partial=True)
    else:
        # If it's a new record, create it
        serializer = DoctorAvailabilitySerializer(availability, data=request.data)

    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED if created else status.HTTP_200_OK)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
