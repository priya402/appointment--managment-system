import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { BsFillPhoneFill } from 'react-icons/bs';
import '../../css/ViewPatient.css';
import defaultImg from "../../assets/imgs.webp"; // Default image
import CustomAlert from '../CustomeAlert'
const ViewPatient = () => {
    const [patients, setPatients] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showAlert, setShowAlert] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
  

    const navigate = useNavigate();

    // Fetch patient data from backend
    useEffect(() => {
        const fetchPatients = async () => {
            try {
                const response = await axios.get("http://localhost:8002/pationt/patients/get-all/"); // Update with your API URL
                setPatients(response.data);
                setAlertMessage("Patient details found");
                setAlertVariant("success");
                setShowAlert(true);
         
            } catch (err) {
                setAlertMessage("error to fetch ,Please try again");
                setAlertVariant("danger");
                setShowAlert(true);
         
            } finally {
                setLoading(false);
            }
        };

        fetchPatients();
    }, []);

    // Handle patient view
    const handleViewPatient = (id) => {
        navigate(`/patient/${id}`);
    };

    if (loading) {
        return <p>Loading patients...</p>;
    }


    return (
        <>
          <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        /> 
 
        <main className="patients-container">
            <div className="row">
                <div className="col-12">
                    <h3 className="patients-title">View All Patients</h3>
                </div>
            </div>

            <div className="row mt-4">
                {patients.length === 0 ? (
                    <p>No patients found.</p>
                ) : (
                    patients.map((patient) => (
                        <div key={patient.id} className="col-md-3 col-sm-6 mb-4">
                            <div className="card patient-card">
                                <div className="card-body">
                                    <div className="patient-header">
                                        {/* Patient Image (Handle Base64) */}
                                        <div className="patient-image">
                                            <img 
                                                src={patient.profile_image ? patient.profile_image : defaultImg} 
                                                alt={patient.name} 
                                                className="img" 
                                            />
                                        </div>
                                        {/* Name */}
                                        <div className="patient-infos">
                                            <h5>{patient.name}</h5>
                                        </div>
                                    </div>

                                    <div className="patient-summary">
                                        <p><BsFillPhoneFill /> {patient.phone}</p>
                                        <p>{patient.address}</p>
                                    </div>

                                    <div className="patient-actions">
                                        <button className="btn btn-view" onClick={() => handleViewPatient(patient.patient_id)}>
                                            View Patient
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </main>
        </>
    );
};

export default ViewPatient;
