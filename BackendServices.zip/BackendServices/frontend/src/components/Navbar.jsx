import React from "react";
import '../css/Navbar.css';
import { Link ,useNavigate} from "react-router-dom";
const Navbar = () => {
  const role = localStorage.getItem("role");
  const navigate = useNavigate(); 
  const handleLogout = () => {
    localStorage.clear(); // Clears all data from localStorage
    navigate("/", { replace: true });
    window.location.reload(); // Redirects to the login page
  };
  return (
    <div className="vertical-navbar-container d-flex flex-column">
      {/* Vertical Navbar */}
      <nav className="navbar navbar-expand-lg bg-light p-3">
        <h4 className="text-center mb-4 text-primary navbar-header">
          {role === "admin" && "Hospital Admin"}
          {role === "user" && "User Dashboard"}
          {role === "doctor" && "Doctor Dashboard"}</h4>
        <button className="navbar-toggler d-md-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>


        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav flex-column">
            
            {role === "admin" && (<>
              <li className="nav-item mb-2">
              <Link to="/dashboard" className="nav-link text-dark d-flex align-items-center">
                <i className="bi bi-speedometer2 me-3"></i>
                <span>Dashboard</span>
              </Link>
            </li>
              <li className="nav-item mb-2 dropdown">
                <Link to="#patients" className="nav-link text-dark dropdown-toggle d-flex align-items-center" id="patientsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i className="bi bi-people me-3"></i>
                  <span>Patients</span>
                </Link>
                <ul className="dropdown-menu flex-column" aria-labelledby="patientsDropdown">
                  <li><Link className="dropdown-item" to="/view-patient">View Patients</Link></li>
                  <li><Link className="dropdown-item" to="/add-patient">Add Patients</Link></li>
                </ul>
              </li>
              <li className="nav-item mb-2 dropdown">
                <Link to="#appointments" className="nav-link text-dark dropdown-toggle d-flex align-items-center" id="appointmentsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i className="bi bi-calendar3 me-3"></i>
                  <span>Appointments</span>
                </Link>
                <ul className="dropdown-menu flex-column" aria-labelledby="appointmentsDropdown">
                  <li><Link className="dropdown-item" to="/view-appointments">View Appointments</Link></li>
                  <li><Link className="dropdown-item" to="/schedule-appointments">Schedule Appointments</Link></li>
                </ul>
              </li>
              <li className="nav-item mb-2 dropdown">
                <Link to="#doctors" className="nav-link text-dark dropdown-toggle d-flex align-items-center" id="doctorsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i className="bi bi-person-badge me-3"></i>
                  <span>Doctors</span>
                </Link>
                <ul className="dropdown-menu flex-column" aria-labelledby="doctorsDropdown">
                  <li><Link className="dropdown-item" to="/view-doctor">View Doctors</Link></li>
                  <li><Link className="dropdown-item" to="/add-doctor">Add Doctors</Link></li>
                </ul>
              </li>
              <li className="nav-item mb-2 dropdown">
                <Link to="#settings" className="nav-link text-dark dropdown-toggle d-flex align-items-center" id="settingsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i className="bi bi-gear me-3"></i>
                  <span>Settings</span>
                </Link>
                <ul className="dropdown-menu flex-column" aria-labelledby="settingsDropdown">
                  <li><Link className="dropdown-item" to="system-settings">System Settings</Link></li>
                  <li><Link className="dropdown-item" to="user-settings">User Settings</Link></li>
                </ul>
              </li>
            </>)}

            {role === "doctor" && (<>
              <li className="nav-item mb-2">
              <Link to="/DoctorDashboard" className="nav-link text-dark d-flex align-items-center">
                <i className="bi bi-speedometer2 me-3"></i>
                <span>Dashboard</span>
              </Link>
            </li>
              <li className="nav-item mb-2 dropdown">
                <Link to="#patients" className="nav-link text-dark dropdown-toggle d-flex align-items-center" id="patientsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i className="bi bi-people me-3"></i>
                  <span>Patients</span>
                </Link>
                <ul className="dropdown-menu flex-column" aria-labelledby="patientsDropdown">
                  <li><Link className="dropdown-item" to="/DoctorViewPationt">View Patients</Link></li>
                  <li><Link className="dropdown-item" to="/AddPationtNotes">Add Notes</Link></li>
                </ul>
              </li>
              <li className="nav-item mb-2 dropdown">
                <Link to="#appointments" className="nav-link text-dark dropdown-toggle d-flex align-items-center" id="appointmentsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i className="bi bi-calendar3 me-3"></i>
                  <span>Appointments</span>
                </Link>
                <ul className="dropdown-menu flex-column" aria-labelledby="appointmentsDropdown">
                  <li><Link className="dropdown-item" to="/ViewAppointments">View Appointments</Link></li>
                  <li><Link className="dropdown-item" to="/DoctorShedualAppointments">Schedule Appointments</Link></li>
                </ul>
              </li>
              <li className="nav-item mb-2 dropdown">
                <Link to="#doctors" className="nav-link text-dark dropdown-toggle d-flex align-items-center" id="doctorsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i className="bi bi-person-badge me-3"></i>
                  <span>Availablity</span>
                </Link>
                <ul className="dropdown-menu flex-column" aria-labelledby="doctorsDropdown">
                  <li><Link className="dropdown-item" to="/DoctorAvailablity">Update Availablity</Link></li>
                 
                </ul>
              </li>
              <li className="nav-item mb-2 dropdown">
                <Link to="#settings" className="nav-link text-dark dropdown-toggle d-flex align-items-center" id="settingsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i className="bi bi-gear me-3"></i>
                  <span>Performace</span>
                </Link>
                <ul className="dropdown-menu flex-column" aria-labelledby="settingsDropdown">
                  <li><Link className="dropdown-item" to="/DoctorStatistics">Statistics</Link></li>
                </ul>
              </li>
            </>)}
            {role === "user" && (<>
              <li className="nav-item mb-2">
              <Link to="/UserDashboard" className="nav-link text-dark d-flex align-items-center">
                <i className="bi bi-speedometer2 me-3"></i>
                <span>Dashboard</span>
              </Link>
            </li>
              <li className="nav-item mb-2 dropdown">
                <Link to="#patients" className="nav-link text-dark dropdown-toggle d-flex align-items-center" id="patientsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i className="bi bi-people me-3"></i>
                  <span>appointment</span>
                </Link>
                <ul className="dropdown-menu flex-column" aria-labelledby="patientsDropdown">
                  <li><Link className="dropdown-item" to="/BookAppointment">Book Appointment</Link></li>
                  <li><Link className="dropdown-item" to="/ViewAppointment">View Appointment</Link></li>
                </ul>
              </li>
              <li className="nav-item mb-2 dropdown">
                <Link to="#appointments" className="nav-link text-dark dropdown-toggle d-flex align-items-center" id="appointmentsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i className="bi bi-calendar3 me-3"></i>
                  <span>Profile Managment</span>
                </Link>
                <ul className="dropdown-menu flex-column" aria-labelledby="appointmentsDropdown">
                  <li><Link className="dropdown-item" to="/ViewProfile">View Profile</Link></li>
                  <li><Link className="dropdown-item" to="/uploadReports">Uplode reports</Link></li>
                </ul>
              </li>
              <li className="nav-item mb-2 ">
                <Link to="/Notes" className="nav-link text-dark d-flex align-items-center" id="settingsDropdown" role="button" >
                  <i className="bi bi-gear me-3"></i>
                  <span>Notes</span>
                </Link>
              </li>
              <li className="nav-item mb-2 dropdown">
                <Link to="#doctors" className="nav-link text-dark dropdown-toggle d-flex align-items-center" id="doctorsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i className="bi bi-person-badge me-3"></i>
                  <span>Medical Record</span>
                </Link>
                <ul className="dropdown-menu flex-column" aria-labelledby="doctorsDropdown">
                  <li><Link className="dropdown-item" to="/viewPreviousRecords">View Previous Record</Link></li>
                
                </ul>
              </li>
              <li className="nav-item mb-2 dropdown">
                <Link to="#settings" className="nav-link text-dark dropdown-toggle d-flex align-items-center" id="settingsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i className="bi bi-gear me-3"></i>
                  <span>Settings</span>
                </Link>
                <ul className="dropdown-menu flex-column" aria-labelledby="settingsDropdown">
                  <li><Link className="dropdown-item" to="/FeedBack">Feedback</Link></li>
                
                </ul>
              </li>
            </>)}
            <li className="nav-item mb-2 ">
                <Link to="/reports" className="nav-link text-dark d-flex align-items-center" id="settingsDropdown" role="button" >
                  <i className="bi bi-gear me-3"></i>
                  <span>Reports</span>
                </Link>
              </li>
            <li className="nav-item mb-2 ">
                <Link to="/AboutUs" className="nav-link text-dark d-flex align-items-center" id="settingsDropdown" role="button" >
                  <i className="bi bi-gear me-3"></i>
                  <span>About Us</span>
                </Link>
              </li>
            
            <li className="nav-item mb-2">
              <button className="nav-link text-dark d-flex align-items-center" onClick={handleLogout}>
                <i className="bi bi-box-arrow-right me-3"></i>
                <span>Logout</span>
              </button>
            </li>
          </ul>
        </div>
      </nav>

      {/* Main Content */}

    </div>
  );
};

export default Navbar;
