import React, { useState } from "react";
import "../../css/AddPationt.css";

const AddPationt = () => {
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info

  const [newPatient, setNewPatient] = useState({
    name: "",
    age: "",
    gender: "",
    contact: "",
    email: "",
    address: "",
    medicalHistory: "",
    emergencyContact: "",
    patientNumber: "",
    relativeNumber: "",
    relativeName: "",
    relation: "",
    aadharNumber: "",
    image: null, // Patient Image
    aadharImage: null, // Aadhar Image
  });

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewPatient((prev) => ({ ...prev, [name]: value }));
  };

  // Handle file input change for patient image
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewPatient((prev) => ({ ...prev, image: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle file input change for Aadhar image
  const handleAadharImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewPatient((prev) => ({ ...prev, aadharImage: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  // Trigger the file input when the image is clicked
  const handleImageClick = () => {
    document.getElementById("fileInput").click();
  };

  const handleAadharImageClick = () => {
    document.getElementById("aadharFileInput").click();
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(newPatient);
  };

  return (
    <div className="add-patient-container">
      <header className="header">
        <h2>Add New Patient</h2>
      </header>
      <div className="add-patient-card">
        <div className="add-patient-header">
          <div
            className="patient-image-container"
            onClick={handleImageClick}
            style={{
              backgroundImage: newPatient.image
                ? `url(${newPatient.image})`
                : "none", // Display uploaded image or show placeholder
              backgroundColor: newPatient.image ? "transparent" : "#f0f0f0", // Placeholder color
            }}
          >
            {!newPatient.image && (
              <span className="image-placeholder-text">+ Add Image</span>
            )}
          </div>
          <input
            type="file"
            accept="image/*"
            id="fileInput"
            onChange={handleImageChange}
            style={{ display: "none" }} // Hide the input element
          />
        </div>
        <form onSubmit={handleSubmit} className="patient-form">
          <div className="patient-info">
            {[
              { label: "Name", name: "name" },
              { label: "Age", name: "age" },
              { label: "Gender", name: "gender" },
              { label: "Contact", name: "contact" },
              { label: "Email", name: "email" },
              { label: "Address", name: "address" },
              { label: "Medical History", name: "medicalHistory" },
              { label: "Emergency Contact", name: "emergencyContact" },
              { label: "Patient Number", name: "patientNumber" },
              { label: "Relative Number", name: "relativeNumber" },
              { label: "Relative Name", name: "relativeName" },
              { label: "Relation", name: "relation" },
              { label: "Patient Aadhar Number", name: "aadharNumber" },
            ].map(({ label, name }) => (
              <div key={name} className="patient-info-item">
                <label>{label}:</label>
                <input
                  type="text"
                  name={name}
                  value={newPatient[name]}
                  onChange={handleInputChange}
                  className="editable-input"
                />
              </div>
            ))}

            {/* Aadhar Image Field */}
            <div className="patient-info-item">
  <label>Aadhar Image:</label>
  <div
    className="aadhar-image-container"
    onClick={handleAadharImageClick}
  >
    {!newPatient.aadharImage && (
      <span className="aadhar-image-placeholder-text">+ Aadhar Image</span>
    )}
  </div>
  <input
    type="file"
    accept="image/*"
    id="aadharFileInput"
    onChange={handleAadharImageChange}
    style={{ display: "none" }} // Hide the input element
  />
</div>

          </div>

          <div className="action-buttons">
            <button className="btn submit-button" type="submit">
              Submit
            </button>
            <button className="btn cancel-button" type="button">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddPationt;
