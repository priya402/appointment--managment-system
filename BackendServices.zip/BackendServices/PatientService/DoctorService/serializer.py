from rest_framework import serializers
from .models import DoctorDetails

class DoctorSerialiser(serializers.ModelSerializer):
    class Meta:
        model = DoctorDetails
        fields = '__all__'
