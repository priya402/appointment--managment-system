import React, { useState } from "react";
import axios from "axios"; // Import axios for making HTTP requests
import "../../css/UserCss/FeedBackForm.css";
import CustomAlert from '../CustomeAlert'
const FeedbackForm = () => {
  const [feedbackType, setFeedbackType] = useState("complaint");
  const [rating, setRating] = useState(5);
  const [feedbackText, setFeedbackText] = useState("");
 const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success'); // success, danger, warning, info
 
  // Backend API URL (replace with your actual backend URL)
  const backendUrl = "http://localhost:8005/feedback/submit-feedback/"; 

  const handleSubmit = async (e) => {
    e.preventDefault();

    const feedbackData = {
      feedback_type: feedbackType,
      rating: rating,
      feedback_text: feedbackText,
      user_id:localStorage.getItem("user_id")
    };

    try {
      // Send POST request to the backend API
      const response = await axios.post(backendUrl, feedbackData);

      // Handle successful feedback submission
      if (response.status === 201) {
        setAlertMessage("Thank you for your feedback!");
        setAlertVariant("success");
        setShowAlert(true);
 
 
      }
    } catch (err) {
      // Handle error
      setAlertMessage("Failed to submit feedback. Please try again.");
      setAlertVariant("danger");
      setShowAlert(true);
    }
  };

  return (
    <>
      <CustomAlert
          show={showAlert}
          message={alertMessage}
          variant={alertVariant}
          onClose={() => setShowAlert(false)}
        />
    <div className="feedback-form-container">
      <div>
      <h2>Provide Your Valuable Feedback</h2>

      </div>
      <p className="form-instructions">
        Your feedback helps us improve. Please fill out the form below and let
        us know your experience.
      </p>

      {/* Show success or error message */}
     
      <form onSubmit={handleSubmit} className="feedback-form">
        {/* Feedback Type Section */}
        <div className="form-section">
          <h3>Feedback Type</h3>
          <div className="form-group">
            <label>
              <input
                type="radio"
                value="complaint"
                checked={feedbackType === "complaint"}
                onChange={() => setFeedbackType("complaint")}
              />
              Complaint
            </label>
            <label>
              <input
                type="radio"
                value="good"
                checked={feedbackType === "good"}
                onChange={() => setFeedbackType("good")}
              />
              Good Response
            </label>
          </div>
        </div>

        {/* Rating Section */}
        <div className="form-section">
          <h3>Rate Your Experience</h3>
          <div className="form-group">
            <label>Rating (1-5)</label>
            <div className="rating">
              {[1, 2, 3, 4, 5].map((star) => (
                <span
                  key={star}
                  className={`star ${star <= rating ? "filled" : ""}`}
                  onClick={() => setRating(star)}
                >
                  ★
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Feedback Text Section */}
        <div className="form-section">
          <h3>Your Feedback</h3>
          <div className="form-group">
            <label>Additional Comments (Optional)</label>
            <textarea
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              rows="6"
              placeholder="Enter your feedback here. Be as detailed as possible, so we can improve your experience."
            />
          </div>
        </div>

        {/* Submit Button */}
        <div className="form-actions">
          <button type="submit" className="submit-btn">
            Submit Feedback
          </button>
        </div>
      </form>
    </div>
    </>
  );
};

export default FeedbackForm;
